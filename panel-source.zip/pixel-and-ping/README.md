# Pixel & Ping v1.1.1

A Cloudflare-centered VPN management panel — real Cloudflare API integration,
real user/server/endpoint management, a documented ingestion API for actual
traffic/presence data, and an explicit provider architecture for plugging in
a real VPN daemon later.

Links: [GitHub](https://github.com/samyarahad) · [Telegram](https://t.me/Pixel_Ping) · [YouTube](https://youtube.com/@pixel_ping_024?si=IrRQgXUlKWR5N0zS)

---

## Initial login (this fixed build)

The Cloudflare Worker cannot automatically know the email of the Cloudflare account that deployed it. The initial local/deployed application login therefore uses a **password only** flow. On the first login, when D1 contains no administrator, the Worker creates the initial `SUPER_ADMIN` account automatically.

- Password: `admin`
- Email is retained only as an internal database field (`admin@pixelping.local`); it is not requested on the login screen.
- After the first successful login, change the default password before exposing the panel publicly.
- For local `wrangler dev`, the session cookie is allowed over HTTP; deployed HTTPS remains secure.

## Self-provisioned server (no manual "Add Server" step)

The Worker's own public domain — whatever it turns out to be (a
`*.workers.dev` subdomain, or a custom domain attached later) — is
automatically registered as a Server/Endpoint (`worker/src/services/
selfServerService.ts`) the first time any request reaches it. This
mirrors the "first login bootstraps the admin" flow above: no deploy
hook, no migration, no form to fill in — you just `wrangler deploy` and
the panel already has one working node named after your Worker's real
domain, matching the `VPN_PROVIDER="worker-relay"` built-in relay this
project already ships. Creating a user no longer requires picking a
server either — it defaults to this one if omitted.

This doesn't remove the Server/Endpoint concept: `worker/src/routes/
servers.ts` and `endpoints.ts` are untouched, so multi-server/failover
setups (registering additional real VPS nodes) still work exactly as
before. The auto-provisioned row (fixed id `self-worker`) just can't be
deleted from the panel, since it would be re-created on the very next
request anyway — disable it instead if you don't want it used.

## Testing status — read this first

This project was built entirely in a sandboxed environment **with no
outbound network access** (confirmed: `npm install` returns `403
Forbidden` from the egress proxy). Nothing below was live-tested. Every
claim in this README is one of exactly these categories:

| Label | Meaning |
|---|---|
| **Implemented** | Code is written and complete. |
| **Statically reviewed** | Read through by hand (and, where possible, cross-checked programmatically — see "Schema parity" below) for logical/type correctness — imports resolve, routes match, Prisma/Drizzle relations pair up, i18n keys are complete across all 4 locales, BigInt serialization is handled. Not executed. |
| **Locally tested** | Not applicable anywhere in this project — nothing has been run. |
| **Requires database migration** | `npx prisma migrate dev` (Postgres) or `wrangler d1 migrations apply` (D1) has never been run; do this before first boot. |
| **Requires a Cloudflare account** | Needed for `wrangler login`, D1, KV, and Cloudflare API/Analytics integration. |
| **Requires D1/KV creation** | `wrangler d1 create` / `wrangler kv namespace create` have never been run; `wrangler.toml` has placeholder IDs that must be replaced with real ones. |
| **Requires Wrangler deployment** | `wrangler dev`/`wrangler deploy` have never been run — no network access in this build environment. |
| **Requires live Cloudflare credentials** | Needs a real Cloudflare API token to exercise account verification, zones, and analytics. |
| **Requires an authorized VPN/provider backend** | Needs you to implement `VpnProvider` against real infrastructure — see "Cloudflare-native VPN/proxy capability" below. |
| **Cloudflare product limitation** | Not a bug in this codebase — Cloudflare's platform genuinely doesn't do this; documented rather than worked around. |

Nothing here is "fully tested" — treat first boot as the actual test and
expect to fix the shallow issues (env var typos, a missed npm package
version) that only surface once real tools run.

---

## Two backends: which one to use

This repository contains **two complete backend implementations** of the
same application, sharing the same frontend and the same `/api/*`
contract:

| | `worker/` (Cloudflare Workers + Hono + D1 + KV) | `backend/` (Node + Express + Prisma + PostgreSQL) |
|---|---|---|
| Status | **Current, recommended** | Preserved, legacy/alternative |
| Requires a VPS/server | **No** | Yes |
| Database | Cloudflare D1 (SQLite) | PostgreSQL |
| Deploy command | `wrangler deploy` | `docker compose up` / your own process manager |
| Scheduler | Cloudflare Cron Triggers | Node `setInterval` |

**If you don't have a VPS and don't want one, use `worker/`.** It's the
architecture documented in the rest of this section. `backend/` remains
fully intact for anyone who already runs a server and prefers a
traditional Postgres deployment — nothing there was deleted or degraded
while `worker/` was built.

## Cloudflare-native architecture (worker/)

```
React frontend (frontend/) — same UI, same components, same i18n
        │
        ▼
Cloudflare Worker (worker/src/index.ts) — Hono router
        │
        ├──► Cloudflare D1 (SQLite) — ALL relational data via Drizzle ORM
        │      users, servers, endpoints, configs, traffic, logs, etc.
        │
        ├──► Cloudflare KV — CACHE ONLY (Cloudflare API response cache,
        │      ingestion rate-limit counters). Never a source of truth.
        │
        ├──► Official Cloudflare REST + GraphQL Analytics API (fetch())
        │
        └──► `cloudflare:sockets` connect() — real outbound TCP/TLS probes
               for the IP Scanner / health-check system
```

One `wrangler deploy` ships both the API (the Worker) and the built React
app (served as static assets from the same Worker via the `[assets]`
binding in `wrangler.toml`) — no separate static host, no VPS, no
persistent Node process, no PostgreSQL/MySQL/Redis.

### What changed vs. the Node backend, and why

Every change below was forced by the Workers runtime, not a redesign of
the product:

- **Prisma → Drizzle ORM.** Prisma's query engine is a native binary that
  doesn't run in the Workers V8 isolate; Prisma's own edge story
  (Accelerate/Data Proxy) means routing every query through an external
  Prisma-hosted proxy, which reintroduces the "extra always-on service"
  problem this migration exists to avoid. Drizzle is a lightweight
  TypeScript query builder with first-class D1 support and no runtime
  dependency beyond D1 itself. `worker/src/db/schema.ts` mirrors
  `backend/prisma/schema.prisma`'s 20 models field-for-field (verified
  programmatically — see "Schema parity" below).
- **PostgreSQL → D1.** D1 is Cloudflare's own SQLite-based database,
  bound directly to the Worker — no connection string, no separate
  database host to run or pay for.
- **Node `crypto`/`jsonwebtoken` → Web Crypto API.** `worker/src/lib/crypto.ts`
  re-implements the AES-256-GCM token encryption using `SubtleCrypto`
  (native to the Workers runtime); `worker/src/lib/jwt.ts` is a ~40-line
  HS256 JWT sign/verify using the same API, replacing the `jsonwebtoken`
  npm package rather than hoping it runs unmodified under `nodejs_compat`.
- **`net`/`tls` sockets → `cloudflare:sockets` `connect()`.** See "IP
  Scanner / health checks" below — this is a real, documented Workers
  capability, not a workaround.
- **`setInterval` scheduler → Cron Triggers.** Workers have no persistent
  process to run a loop in. `worker/src/scheduled.ts` runs on
  `wrangler.toml`'s `[triggers] crons` schedule (every 5 minutes by
  default) instead of the three 30-second/5-minute `setInterval` loops
  the Node backend used. This is a real trade-off, not free: reaction
  time to a failed health check or a stale presence heartbeat is bounded
  by the cron interval, not sub-minute. Lower the cron interval (down to
  Cloudflare's 1-minute minimum) if your deployment needs tighter timing.
- **bcryptjs / otplib / qrcode** are kept as-is — all three are pure
  JavaScript (or rely only on APIs Workers' `nodejs_compat` polyfills)
  and were not rewritten. This is the one area of the Workers backend
  that is **not yet verified by actually running it** (see Testing status
  below) — these packages are widely used on Workers by other projects,
  but this repo hasn't executed them here.

### Schema parity (D1 vs. the original Postgres schema)

`worker/src/db/schema.ts` (Drizzle) and `worker/migrations/0001_init.sql`
(hand-written, since `drizzle-kit generate` couldn't run without network
access) were cross-checked against each other programmatically: **20
tables, every column, identical on both sides** — see
`worker/migrations/README.md` for the exact verification method and why
no auto-generated migration exists yet. The SQL migration was **not**
applied to a real D1 database in this environment (no `wrangler`
authentication, no network) — run `wrangler d1 migrations apply
pixelping --local` yourself as the actual first test of this schema.

### Cloudflare-native VPN/proxy capability — read this section carefully

This is the single most important limitation to understand before relying
on this architecture for real VPN traffic:

**Cloudflare Workers do not run a generic VPN server, and this project
does not pretend they do.** What Workers actually, genuinely support,
used correctly in this codebase:

- **Outbound TCP/TLS sockets** via `connect()` from `cloudflare:sockets`
  (`worker/src/services/healthCheckService.ts`) — real, confirmed via
  Cloudflare's own documentation, used here for genuine reachability
  probing of endpoints already in your own inventory. The same API is
  the real, documented mechanism that Cloudflare-Worker-based proxy
  projects (including the one cited as an architectural reference for
  this task) use to relay traffic: a client speaks a protocol
  (VLESS/Trojan/etc.) over WebSocket to the Worker, the Worker parses
  that protocol's framing in JavaScript, and uses `connect()` to open a
  raw TCP socket to the actual destination — meaning the Worker itself
  becomes the relay/exit point, with **no VPS required for that specific
  mechanism**.
- **This project does not ship that protocol parser.** Implementing
  VLESS/Trojan/Shadowsocks framing correctly (binary header parsing,
  UUID/auth validation, padding, multiplexing) is a substantial,
  security-sensitive undertaking on its own — getting it subtly wrong
  is a real vulnerability, not a cosmetic bug. Shipping a half-verified
  implementation and calling it "VPN support" would be exactly the kind
  of fabrication this task explicitly forbids. What's here instead is
  the honest foundation: a real TCP-socket capability
  (`healthCheckService.ts`), a `VpnProvider` interface
  (`worker/src/providers/types.ts`) documented as the seam where a real,
  properly-implemented relay would plug in, and `NullVpnProvider`
  (`worker/src/providers/nullVpnProvider.ts`) which truthfully reports
  `PENDING`/no-op rather than claiming success.
- **Real, documented Workers platform constraints** on `connect()` that
  any future relay implementation must design around: outbound sockets
  to Cloudflare's own IP ranges are blocked, port 25 is blocked, and a
  socket cannot be created outside a request-handling context — all
  consistent with this project's existing "only ever probe/relay to
  operator-registered endpoints" posture, never arbitrary third-party
  hosts.
- **Cloudflare Tunnel / cloudflared** is the officially-supported,
  production-grade way to expose a real backend service through
  Cloudflare's edge without a public VPS IP — but it still requires
  something running that tunnel client somewhere (a home server, a
  container host, etc.), so it does not eliminate "a server exists"
  the way a Worker-native relay can. Not implemented here; noted as a
  legitimate alternative if a from-scratch protocol parser is more risk
  than you want to take on.

**Bottom line:** Config Generator output is a real, well-formed
connection string built from real stored data, with the Cloudflare
DNS/zone portion (if used) live-verified — exactly as before. Whether
that config actually connects to anything depends entirely on which
`VpnProvider` is configured. With the shipped `NullVpnProvider`, it
doesn't, and the UI says so via `provisioningStatus: "PENDING"` rather
than a false "Active".

## Cloudflare-native deployment

```bash
cd worker
npm install
npx wrangler login                      # authenticate with your Cloudflare account
npx wrangler d1 create pixelping        # copy the returned database_id into wrangler.toml
npx wrangler kv namespace create PIXELPING_KV   # copy the returned id into wrangler.toml
npx wrangler d1 migrations apply pixelping --local    # for `wrangler dev`
npx wrangler d1 migrations apply pixelping --remote   # for production

npx wrangler secret put JWT_SECRET
npx wrangler secret put ENCRYPTION_KEY
# for local dev instead, copy .dev.vars.example -> .dev.vars and fill it in

cd ../frontend
npm install
npm run build                            # produces frontend/dist, which worker/wrangler.toml points at

cd ../worker
npx wrangler dev                         # local dev server, http://localhost:8787
npx wrangler deploy                      # ships both the API and the built frontend
```

None of this was run in this environment (no network, no Cloudflare
account access). Every command above is what you need to run yourself;
expect the first real `wrangler dev` to surface issues this static
review couldn't catch — most likely around the `bcryptjs`/`otplib`/
`qrcode` package compatibility noted above, since the Workers runtime's
Node compatibility, while extensive, does not cover 100% of the Node API
surface these packages might touch.

---

## Architecture

```
Frontend (React + TS + Vite + Tailwind, 4 languages incl. RTL Persian)
        |  same-origin /api/*, httpOnly session cookie -- never a Cloudflare
        |  token, never localStorage
        v
Backend (Node + Express + TS)
        |
        |--> PostgreSQL (via Prisma) -- source of truth for everything
        |
        |--> Official Cloudflare API + GraphQL Analytics API
        |      (server-side only, token encrypted at rest -- see below)
        |
        `--> Ingestion API (/api/ingest/*, separate API-key auth) <-- an
               authorized external VPN daemon / metering sidecar calls
               this to report REAL traffic and presence data. Nothing in
               this repo simulates that daemon.
```

### Provider architecture

The backend is written against interfaces, not concrete implementations,
so a real integration can be dropped in without touching routes or the
frontend. All defined in `backend/src/providers/types.ts`:

| Interface | Ships with | What it's for |
|---|---|---|
| `TrafficProvider` | `DatabaseTrafficProvider` (real -- the only implementation needed; it's the sink ingestion writes to) | Records/reads upload, download, and request counts. Idempotency-key protected. |
| `PresenceProvider` | `DatabasePresenceProvider` (real) | Heartbeat -> `ConnectionSession` rows -> `VpnUser.isOnline`. Stale-session cleanup. |
| `VpnProvider` | `NullVpnProvider` (**honest no-op** -- see below) | Actual VPN **server provisioning** -- making a daemon accept a generated config. |
| `CloudflareProvider` | `CloudflareApiProvider` (real, wraps `services/cloudflareService.ts`) | Thin interface seam over the real Cloudflare API calls. |

Selection happens once, in `backend/src/providers/index.ts` -- an env var
(`VPN_PROVIDER`) picks the concrete class. To go live with a real VPN
backend, implement `VpnProvider` against your orchestration layer (SSH to
the box, a REST call to your daemon's API, a message onto a queue it
consumes -- whatever fits your infra) and add a `case` for it in that
factory. No other file needs to change.

### Config generation vs. VPN provisioning -- read this carefully

These are **deliberately two different things**, and the UI never
conflates them:

- **Config generation** (`services/configService.ts`) always succeeds
  against valid stored data. It builds a real `vless://` / `trojan://` /
  WireGuard-style config string from the user's actual server/port/
  protocol/UUID -- never a placeholder. If a Cloudflare hostname is
  attached, it's verified live (zone ownership + DNS record existence)
  against the real Cloudflare API before the string is built; generation
  is **refused** if that verification fails.
- **VPN provisioning** (`services/vpnProvisioningService.ts` ->
  `VpnProvider.provisionUser()`) is a separate, best-effort step that
  attempts to make a real server actually accept that config. This
  project ships with `NullVpnProvider`, which does nothing and says so:
  every call returns `{ status: "PENDING", message: "No VpnProvider is
  configured..." }`. `VpnUser.provisioningStatus` and
  `.provisioningMessage` record this truthfully, and both the Create
  User result screen and the Config Generator page display it --
  **the UI never implies a working VPN server exists just because a
  configuration string was generated.**

**Cloudflare does not provision arbitrary VPN protocols.** There is no
official Cloudflare API that creates a VLESS/Trojan/Shadowsocks endpoint.
Cloudflare's role here is strictly what its real APIs support: DNS
records, zone management, and (where the account/token has access) usage
analytics. Anything beyond that -- actually running and configuring a VPN
daemon -- is `VpnProvider`'s job, and requires you to bring your own
authorized backend.

---

## Real VPN deployment

To go from "panel with real Cloudflare integration" to "panel operating
a real fleet of VPN connections", you need to supply two things this
repo intentionally does not ship:

### 1. A VpnProvider implementation

Implement `backend/src/providers/types.ts#VpnProvider` against your real
VPN daemon/orchestration layer:

```ts
export interface VpnProvider {
  readonly name: string;
  provisionUser(params: { userId, serverId, protocol, port, uuid }): Promise<VpnProvisionResult>;
  deprovisionUser(params: { userId, serverId }): Promise<VpnProvisionResult>;
}
```

Register it in `providers/index.ts`'s `selectVpnProvider()` factory and
set `VPN_PROVIDER=<your-name>` in `.env`.

### 2. A reporter that calls the ingestion API

Your VPN daemon (or a sidecar next to it) needs to push real traffic and
presence data. This project defines the ingestion contract; **you write
the reporter** -- nothing here generates or simulates that traffic.

#### Authentication

All ingestion endpoints require a long-lived API key, issued from
**Settings -> Ingestion API Keys** in the panel (admin session required to
create one; the panel never re-displays the plaintext after creation).
Send it as:

```
Authorization: Bearer pp_live_<64 hex chars>
```

Keys carry scopes (`TRAFFIC_INGEST`, `PRESENCE_INGEST`, `FULL_INGEST`) --
this is a completely separate credential system from admin login; an
ingestion key can never authenticate to `/api/auth/*` or the interactive
admin API.

#### `POST /api/ingest/traffic`

```jsonc
// Request
{
  "userId": "...",            // or "username": "..." -- one required
  "uploadBytes": 12345678,    // bytes this reporting period
  "downloadBytes": 87654321,
  "periodStart": "2026-08-30T00:00:00Z",
  "periodEnd":   "2026-08-30T01:00:00Z",
  "requestCount": 4210,        // optional
  "isEstimated": false,        // default true -- set false only from an authoritative meter
  "idempotencyKey": "daemon-generated-uuid-per-report"   // strongly recommended
}
// Response: 201 (or 200 if idempotencyKey already seen)
{ "traffic": { "created": true, "id": "..." }, "requests": { "created": true, "id": "..." } }
```

DB effect: one `TrafficUsage` row (+ one `RequestUsage` row if
`requestCount` given). Duplicate `idempotencyKey` -> no new row, existing
id returned -- safe to retry on network failure. Also auto-suspends the
user if their configured `trafficLimitBytes`/`requestLimit` is now
exceeded (and fires a notification).

#### `POST /api/ingest/heartbeat`

```jsonc
{
  "userId": "...", // or "username"
  "serverId": "...", "endpointId": "...",  // optional, which server/endpoint they're on
  "clientIp": "203.0.113.4",
  "connectionSessionId": "..."              // omit on first heartbeat; include on subsequent ones
}
// Response: { "connectionSessionId": "..." }
```

Call every 30-60s per connected user. DB effect: opens/refreshes a
`ConnectionSession`, sets `VpnUser.isOnline = true`,
`lastSeenAt = now()`. If no heartbeat arrives within
`PRESENCE_TIMEOUT_SEC` (default 90s), the scheduled cleanup job marks the
user offline automatically.

#### `POST /api/ingest/session/end`

```jsonc
{ "connectionSessionId": "...", "reason": "client_disconnect" }
// Response: { "ok": true }
```

Call this on a clean disconnect to mark the user offline immediately
instead of waiting for the timeout.

#### `GET /api/ingest/ping`

Diagnostic -- confirms a key is valid and returns its scopes. No body.

**Dashboard "Online Users" and all traffic figures are 100% derived from
this ingestion data.** With no reporter running, online count stays 0 and
Traffic shows "no records yet" -- this is correct behavior, not a bug.

### What Cloudflare *can* tell you without any of the above

If your VPN traffic actually flows through a Cloudflare-fronted
hostname/zone (e.g. you tunnel through Cloudflare), the **Traffic** page's
"Cloudflare edge traffic" section shows real, zone-level
requests/bandwidth pulled from the GraphQL Analytics API -- no ingestion
API or VpnProvider required for that section. What Cloudflare's API
genuinely cannot do is attribute that edge traffic to an individual VPN
user; per-user attribution needs either your own ingestion reporter (as
above) or a Workers Analytics Engine binding you build yourself. Where
neither exists, the UI says exactly that: "User-level traffic unavailable
from current data source" -- never a fabricated per-user split of a
zone-level number.

---

## Cloudflare integration architecture

```
Backend
  | (bearer token, decrypted in-memory per request only)
  v
Official Cloudflare REST API (/client/v4/...)  +  GraphQL Analytics API
  v
services/cloudflareService.ts -- retry w/ backoff on 429/5xx, verifies
  token via /user/tokens/verify before ever saving one, per-zone sync
  v
CloudflareUsageSnapshot rows (one per zone per sync), each carrying its
  own `dataAvailable` flag and `source` label ("Cloudflare GraphQL
  Analytics API" or "Unavailable from Cloudflare API")
  v
/api/analytics/cloudflare-usage -- aggregates latest-per-zone-per-day
  snapshots into today/7d/30d totals (Traffic page range selector)
```

- **Token security**: AES-256-GCM encrypted at rest
  (`backend/src/lib/crypto.ts`), decrypted only in-memory for the
  duration of a single request. Never sent to the frontend, never in
  localStorage, never in a URL, never logged (`redactToken()` is used
  anywhere a token might otherwise reach a log line).
- **Verification before save**: adding an account calls
  `/user/tokens/verify` against the real API before the token is
  persisted at all.
- **Retry/backoff**: `cfFetch()` retries up to 3 attempts with
  exponential backoff (respecting `Retry-After` when Cloudflare sends
  one) on 429 and 5xx; 401/403 fail immediately (retrying a bad token
  never helps).
- **Never fabricated**: every Cloudflare-sourced number carries a
  `dataAvailable` boolean and a `source` string. When a metric genuinely
  isn't obtainable (no zones, token lacks Analytics scope, GraphQL
  returns nothing), the row is stored with `dataAvailable: false,
  source: "Unavailable from Cloudflare API"` -- the UI renders that
  explicitly rather than defaulting to 0 or omitting the row silently.
- **Zone/DNS verification for Config Generator**: see "Config generation
  vs. VPN provisioning" above -- `verifyZoneOwnership()` and
  `findDnsRecord()` in `cloudflareService.ts` back this.
- **Workers**: `listWorkers()` returns `null` (-> "Unavailable from
  Cloudflare API" in the UI) if the token lacks Workers Scripts scope,
  rather than an empty array indistinguishable from "no workers exist".

---

## Features implemented

- **Auth**: session cookie (JWT + revocable DB-backed `Session` row --
  logout actually invalidates it, not just a client-side cookie clear),
  bcrypt password hashing (cost 12), full **2FA** (TOTP setup -> QR code ->
  verify -> recovery codes shown once and bcrypt-hashed at rest -> login
  with code or recovery code -> disable with password step-up
  confirmation), login rate limiting, RBAC (`SUPER_ADMIN`/`ADMIN`/
  `VIEWER`).
- **Users**: create/edit/delete, suspend/enable, expiration (auto-swept
  by a scheduled job -> `EXPIRED` status + notification), traffic/request
  limits (auto-suspend on breach via the ingestion provider), optional
  preferred endpoint, server assignment, real generated config with
  copy/QR/download, Cloudflare zone/hostname verification at creation
  (creation is rolled back if verification fails -- no orphaned user
  records), VPN provisioning status surfaced honestly.
- **Servers & Endpoints**: CRUD, enable/disable, real TCP/TLS health
  probes (`net`/`tls` sockets against your own registered inventory
  only -- no arbitrary scanning), weighted/primary endpoint model,
  server-offline notification on health-check failure.
- **IP Scanner**: 0-100 score from real recent health-check
  success-rate + latency, health label
  (Excellent/Good/Fair/Poor/Offline), sort/filter/CSV export, unhealthy<->
  recovered transition notifications.
- **Ports**: TLS/non-TLS presets (seeded), custom ports, a real same-host
  bind test before a port is ever marked active.
- **Cloudflare accounts**: add (token verified live before saving), test
  connection, enable/disable, remove, per-zone usage sync with
  retry/backoff, list zones, list workers (honest `null` when
  unavailable).
- **Config Generator**: real per-protocol strings from stored data,
  optional live-verified Cloudflare zone/hostname attachment, versioned
  history, revoke, provisioning-status display.
- **Traffic**: internal per-user accounting from the ingestion API
  (upload/download/total, estimated-vs-authoritative flag, "no records
  yet" honest empty state) **and** real Cloudflare edge traffic per zone
  with a today/7-day/30-day range selector, manual "sync now", and each
  connected account's last-sync time/error.
- **Presence**: real heartbeat-driven online/offline via
  `ConnectionSession`, configurable timeout, scheduled stale-session
  cleanup, immediate offline on clean disconnect via
  `/api/ingest/session/end`.
- **Failover**: configurable failure/recovery thresholds, retry count,
  health-check interval, 4 strategies; on failure, verifies the
  candidate with a **fresh** health probe before switching (never trusts
  stale health); on sustained recovery (`recoveryThreshold` consecutive
  successes + score parity), automatically fails back; every switch is a
  logged `FailoverEvent` + notification.
- **Logs & Notifications**: full activity log (admin-only, secrets never
  written to it), notification feed covering user-expired,
  server-offline, endpoint-unhealthy/recovered, failover, traffic/request
  limit breaches, Cloudflare sync errors.
- **i18n**: English, Persian (genuine `dir="rtl"` at the document level),
  Russian, Chinese -- 110 translation keys, verified byte-for-byte parity
  across all four locale files (see Final audit below).
- **Security**: helmet, CORS locked to `FRONTEND_ORIGIN`, two separate
  rate limiters (interactive API + a higher-throughput one for
  machine-to-machine ingestion), Zod validation on every mutating route,
  no secrets in the frontend bundle/localStorage/URLs/logs, sanitized
  error responses, BigInt-safe JSON serialization globally.

## What still needs real-world work

- **A `VpnProvider` implementation** -- see "Real VPN deployment" above.
  Without one, `provisioningStatus` stays `PENDING` forever with an
  honest explanatory message; the panel manages configuration and
  Cloudflare-side resources but does not itself run a VPN server.
- **A traffic/presence reporter** -- your VPN daemon (or a sidecar) must
  call `/api/ingest/traffic` and `/api/ingest/heartbeat`. Without it,
  Online Users stays 0 and Traffic shows no internal records -- correct,
  not broken.
- **Database migration** -- `npx prisma migrate dev --name init` has
  never been run (no network in this environment). See
  `backend/prisma/migrations/README.md`.
- **`npm install` in both `backend/` and `frontend/`** -- never run here;
  confirmed blocked (`403 Forbidden` from the registry) when attempted.
- **Live Cloudflare credentials** -- token verification, zone/DNS lookups,
  GraphQL analytics, and Workers listing all need a real account to
  exercise even once.
- **Automated tests** -- `vitest` is scaffolded in `package.json` but no
  test files exist yet.
- **Workers Analytics Engine** -- per-request/per-user Worker-side
  attribution is architecturally noted (see "Real VPN deployment") but
  not implemented; it requires a Worker you deploy yourself with a bound
  Analytics Engine dataset.

## Requirements

- Node.js 20+
- PostgreSQL 16+ (or the bundled Docker Compose service)
- A Cloudflare account + a scoped API token (`Zone:Read`, `Account:Read`,
  `Zone Analytics:Read` minimum; add `Workers Scripts:Read` for the
  Workers list; add `DNS:Read` if you'll use hostname verification in the
  Config Generator)

## Installation (local, without Docker)

```bash
# 1. Backend
cd backend
cp .env.example .env
# edit .env -- at minimum set DATABASE_URL, JWT_SECRET, ENCRYPTION_KEY:
#   openssl rand -base64 32   -> ENCRYPTION_KEY
#   openssl rand -hex 32      -> JWT_SECRET
npm install
npx prisma migrate dev --name init
npm run prisma:seed        # creates admin / ChangeMe123! -- change immediately
npm run dev                # http://localhost:4000

# 2. Frontend (separate terminal)
cd ../frontend
npm install
npm run dev                # http://localhost:5173 (proxies /api to :4000)
```

Log in with `admin@pixelping.local` / `ChangeMe123!` and change the
password immediately -- there is no self-service password-change endpoint
yet; update it via `prisma studio` or add one before exposing this
publicly. Enable 2FA immediately after from **Settings**.

## Environment variables

Full list in `backend/.env.example`. Beyond the basics (`DATABASE_URL`,
`JWT_SECRET`, `FRONTEND_ORIGIN`, `COOKIE_SECURE`):

| Variable | Purpose |
|---|---|
| `ENCRYPTION_KEY` | 32-byte base64 key encrypting Cloudflare tokens at rest |
| `PRESENCE_TIMEOUT_SEC` | Seconds without a heartbeat before auto-offline (default 90) |
| `VPN_PROVIDER` | Which `VpnProvider` to load (`null` by default -- see above) |
| `RATE_LIMIT_*` | Interactive API rate limiting |

## Database / Prisma

Schema: `backend/prisma/schema.prisma` -- 20 models, 9 enums, internally
consistent (every named relation paired, every back-relation present,
brace-balanced -- verified by script, not by running Prisma). Notable
models added across this project's build: `ApiKey`,
`TwoFactorRecoveryCode`, `ConnectionSession`, plus `ProvisioningStatus`
and `ApiKeyScope` enums, and per-zone fields on
`CloudflareUsageSnapshot`.

After any schema edit:

```bash
npx prisma migrate dev --name <description>
npx prisma generate
```

Production: `npx prisma migrate deploy` (already the backend service's
Docker Compose startup command). See `backend/prisma/migrations/README.md`
for why no migration SQL is checked in yet.

## Docker

```bash
cp backend/.env.example backend/.env   # fill in JWT_SECRET / ENCRYPTION_KEY
docker compose up --build
```

- Frontend: http://localhost:8080 (nginx, proxies `/api` to the backend
  container)
- Backend API: http://localhost:4000/api
- Postgres: localhost:5432

**Not built/tested here** (no network to pull base images or npm
packages). One real bug was found and fixed by static review during this
build: the backend `Dockerfile`'s deps stage originally ran `npm install
--omit=dev=false`, which is invalid npm syntax -- corrected to plain
`npm install` (dev dependencies, including the Prisma CLI needed at
runtime for `migrate deploy`, are required in the image regardless).

## Production deployment notes

- TLS in front of everything; set `COOKIE_SECURE=true` once you do.
- Rotate `JWT_SECRET`/`ENCRYPTION_KEY` out of the example defaults.
- `prisma migrate deploy`, not `migrate dev`, in production.
- Back up Postgres on a schedule.
- Issue ingestion API keys with the narrowest scope your reporter needs
  (`TRAFFIC_INGEST` / `PRESENCE_INGEST` rather than `FULL_INGEST`) and
  revoke unused ones from Settings.

## Security

- No Cloudflare token, JWT secret, ingestion API key, or password ever
  reaches a frontend bundle, localStorage, or a URL. Ingestion keys are
  bcrypt-hashed at rest; only a key's 16-character prefix is ever shown
  again after creation, for identification.
- All Cloudflare API calls happen server-side only.
- Passwords: bcrypt cost 12. Sessions: httpOnly, `SameSite: Lax` cookies
  backed by a revocable DB row, cookie `maxAge` tied to actual session
  expiry.
- 2FA: TOTP secret held as `twoFactorPendingSecret` until a real code
  confirms it works, never activated on faith; recovery codes are
  bcrypt-hashed, shown once; disabling requires a password step-up, not
  just an active session.
- Rate limiting: separate, appropriately-sized limiters for the
  interactive admin API, `/api/auth/login` specifically, and the
  higher-throughput machine-to-machine ingestion API.
- Ingestion auth is a completely separate credential system from admin
  sessions -- an API key can never touch `/api/auth/*` or any interactive
  route, and an admin session can never call `/api/ingest/*`.
- All mutating routes validate input with Zod.
- BigInt fields (traffic byte counts) are globally, safely serialized to
  strings (`lib/bigintJson.ts`) -- this was a real bug found and fixed
  during review: Express's default JSON serializer throws on raw BigInt,
  which would have 500'd any response containing a user's traffic limit
  or usage figures.

## Troubleshooting

- **"Missing required environment variable" on boot** -- copy
  `backend/.env.example` to `backend/.env` and fill the blanks; the
  server logs exactly which var is missing.
- **Cloudflare account add fails immediately** -- verified live via
  `/user/tokens/verify` before saving; a 401/403 means the token itself
  is invalid or under-scoped, not a panel bug.
- **Dashboard/Traffic show "Unavailable from Cloudflare API"** -- by
  design when a token lacks Analytics scope, the account has no zones, or
  nothing has synced yet in the selected range -- not an error state.
- **Config Generator refuses to generate** -- if a Cloudflare zone/
  hostname was selected, this means live verification against Cloudflare
  failed (zone doesn't belong to that account, or no DNS record exists
  for that hostname). This is intentional: the panel does not fabricate
  configurations against resources it can't confirm exist.
- **Online Users stays at 0 / Traffic shows no records** -- no ingestion
  reporter is running yet. See "Real VPN deployment" above; this is the
  expected state until you point a real VPN daemon at
  `/api/ingest/heartbeat` and `/api/ingest/traffic`.
- **RTL looks wrong** -- confirm `document.documentElement.dir` is `rtl`
  (`frontend/src/i18n/index.ts#applyDirection`); call it yourself if
  embedding pages outside the router.

## Known limitations (explicit)

- No functionality scans hosts/ports outside the operator's own
  registered `Server`/`Endpoint` inventory.
- Cloudflare is never claimed to provision, run, or operate an arbitrary
  VPN protocol -- its role is DNS/zone verification and edge analytics
  only, exactly what its official APIs support.
- Metrics Cloudflare's API can't supply, or that haven't synced yet, are
  always shown as explicitly unavailable -- never zero, never omitted
  silently, never estimated as if real.
- Per-user attribution of Cloudflare edge traffic is not implemented (see
  "Real VPN deployment" -- it requires Workers Analytics Engine or your
  own ingestion reporter); the UI states this plainly rather than
  guessing a per-user split of a zone-level number.
- "Network Optimization" / anti-filtering features are limited to
  endpoint selection, health-based routing, TLS/DNS configuration, and
  retry policy -- nothing here bypasses Cloudflare's own security
  controls or targets infrastructure the operator doesn't own.

## v1.1.1 UI/UX polish pack

This package includes the premium Pixel & Ping visual refresh, the supplied brand mark on Login/sidebar, language flags, selectable themes (Pixel Neon, Dark, Light, Midnight), profile avatar presets/custom avatar upload, and password-change UI/API.

### Local run order

From the repository root:

```bash
npm run install:all
npm run d1:migrate:local
npm run build:frontend
```

Then use two terminals:

```bash
npm run dev:worker
```

and:

```bash
npm run dev:frontend
```

Open `http://localhost:5173/` unless Vite reports another port.

### Important architecture note

The IP Scanner performs real reachability/latency checks only against endpoints already registered in the panel. It does not invent IPs. Cloudflare Workers can perform real outbound TCP probes with the Workers Sockets API, but they cannot be treated as a generic VLESS/Trojan/WireGuard server. Pixel & Ping therefore does not claim that a generated configuration is a live VPN connection unless a real authorized VPN provider/backend is configured.
