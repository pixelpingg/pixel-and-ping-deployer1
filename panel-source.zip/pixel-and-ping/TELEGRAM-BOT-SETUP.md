# Pixel & Ping Telegram Bot

This version adds a Cloudflare-native Telegram bot integration.

## Included
- Inline (glass-style) Telegram keyboards throughout the bot.
- Cloudflare connection flow with direct buttons for login/account creation and the preconfigured Pixel & Ping API Token page.
- Users send only the API Token; Account ID is discovered automatically through Cloudflare API.
- Multiple legitimate Cloudflare accounts per Telegram user.
- AES-256-GCM encrypted token storage; raw tokens are not returned by APIs or written to activity logs.
- Per-user isolation for connected accounts and panel records.
- Admin-only menu using `ADMIN_TELEGRAM_ID`.
- D1-backed bot users, Cloudflare connections, panel requests, bot text settings and emoji library.
- Automatic Telegram webhook registration from the Worker Cron after deployment.

## Required Worker secrets
- `TELEGRAM_BOT_TOKEN` — already configured in the deployed project.
- `JWT_SECRET`
- `ENCRYPTION_KEY`

Optional:
- `TELEGRAM_WEBHOOK_SECRET` — if omitted, the bot token is used as Telegram's webhook secret so no extra setup is required.

## Deploy
From `worker/`:

```text
npx wrangler d1 migrations apply pixelping --remote
npx wrangler deploy
```

After the first Cron execution, the Worker registers:
`/api/telegram/webhook`

## Important limitation
The bot's panel-create flow records a real deployment request but does not claim that a new Worker has been deployed until a real Cloudflare Worker bundle/deployment implementation is connected. This is intentional: the bot must never show a fake panel URL or fake deployment success.
