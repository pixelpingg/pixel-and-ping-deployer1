import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { authenticator } from "otplib";
import { z } from "zod";
import crypto from "crypto";
import { prisma } from "../lib/prisma";
import { env } from "../lib/env";
import { ApiError } from "../lib/errors";
import { asyncHandler } from "../middleware/errorHandler";
import { authRateLimiter } from "../middleware/rateLimit";
import { requireAuth } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";

export const authRouter = Router();

const loginSchema = z.object({
  identifier: z.string().min(1), // email or username
  password: z.string().min(1),
  totpCode: z.string().optional(),
  recoveryCode: z.string().optional(),
});

function cookieOptions(maxAgeMs?: number) {
  return {
    httpOnly: true,
    secure: env.COOKIE_SECURE,
    sameSite: "lax" as const,
    path: "/",
    ...(maxAgeMs ? { maxAge: maxAgeMs } : {}),
  };
}

authRouter.post(
  "/login",
  authRateLimiter,
  asyncHandler(async (req, res) => {
    const { identifier, password, totpCode, recoveryCode } = loginSchema.parse(req.body);

    const admin = await prisma.admin.findFirst({
      where: { OR: [{ email: identifier }, { username: identifier }] },
    });

    // Constant-shape response regardless of which check fails, to avoid
    // user enumeration.
    if (!admin || !admin.isActive) throw ApiError.unauthorized("Invalid credentials");

    const valid = await bcrypt.compare(password, admin.passwordHash);
    if (!valid) throw ApiError.unauthorized("Invalid credentials");

    if (admin.twoFactorEnabled) {
      if (recoveryCode) {
        const unusedCodes = await prisma.twoFactorRecoveryCode.findMany({
          where: { adminId: admin.id, usedAt: null },
        });
        let matchedId: string | null = null;
        for (const c of unusedCodes) {
          if (await bcrypt.compare(recoveryCode, c.codeHash)) {
            matchedId = c.id;
            break;
          }
        }
        if (!matchedId) throw ApiError.unauthorized("Invalid or already-used recovery code");
        await prisma.twoFactorRecoveryCode.update({ where: { id: matchedId }, data: { usedAt: new Date() } });
      } else if (!totpCode) {
        return res.status(200).json({ requiresTwoFactor: true });
      } else {
        const ok = authenticator.check(totpCode, admin.twoFactorSecret ?? "");
        if (!ok) throw ApiError.unauthorized("Invalid 2FA code");
      }
    }

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const session = await prisma.session.create({
      data: {
        adminId: admin.id,
        tokenHash: crypto.randomBytes(32).toString("hex"),
        userAgent: req.headers["user-agent"] ?? undefined,
        ipAddress: req.ip,
        expiresAt,
      },
    });

    // No separate refresh-token endpoint exists yet, so the access token's
    // lifetime is tied to the session's lifetime (REFRESH_TOKEN_EXPIRES_IN)
    // rather than the shorter JWT_EXPIRES_IN — otherwise users would be
    // silently logged out every JWT_EXPIRES_IN with no way to renew.
    const token = jwt.sign(
      { adminId: admin.id, role: admin.role, sessionId: session.id },
      env.JWT_SECRET,
      { expiresIn: env.REFRESH_TOKEN_EXPIRES_IN as any }
    );

    res.cookie(env.SESSION_COOKIE_NAME, token, cookieOptions(expiresAt.getTime() - Date.now()));

    await prisma.admin.update({
      where: { id: admin.id },
      data: { lastLoginAt: new Date(), lastLoginIp: req.ip },
    });

    await logActivity({ adminId: admin.id, action: "auth.login", ipAddress: req.ip });

    res.json({
      admin: { id: admin.id, email: admin.email, username: admin.username, role: admin.role },
    });
  })
);

authRouter.post(
  "/logout",
  requireAuth,
  asyncHandler(async (req, res) => {
    if (req.auth) {
      await prisma.session.update({
        where: { id: req.auth.sessionId },
        data: { revokedAt: new Date() },
      });
      await logActivity({ adminId: req.auth.adminId, action: "auth.logout" });
    }
    res.clearCookie(env.SESSION_COOKIE_NAME, cookieOptions());
    res.json({ ok: true });
  })
);

authRouter.get(
  "/me",
  requireAuth,
  asyncHandler(async (req, res) => {
    const admin = await prisma.admin.findUniqueOrThrow({ where: { id: req.auth!.adminId } });
    res.json({
      admin: {
        id: admin.id,
        email: admin.email,
        username: admin.username,
        role: admin.role,
        twoFactorEnabled: admin.twoFactorEnabled,
      },
    });
  })
);
