import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";
import { checkEndpointHealth } from "../services/healthCheckService";
import { AdminRole } from "@prisma/client";

export const endpointsRouter = Router();
endpointsRouter.use(requireAuth);

const endpointSchema = z.object({
  serverId: z.string().min(1),
  label: z.string().min(1),
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535),
  weight: z.number().int().min(0).max(1000).default(100),
  isPrimary: z.boolean().default(false),
});

endpointsRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const serverId = req.query.serverId as string | undefined;
    const sortBy = (req.query.sortBy as string | undefined) ?? "score";
    const order = (req.query.order as "asc" | "desc" | undefined) ?? "desc";

    const endpoints = await prisma.endpoint.findMany({
      where: serverId ? { serverId } : undefined,
      orderBy: { [sortBy]: order } as any,
      include: { server: { select: { id: true, name: true } } },
    });
    res.json({ endpoints });
  })
);

endpointsRouter.post(
  "/",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    // Ownership guardrail: endpoints may only be created for servers already
    // registered in this operator's own inventory — never arbitrary
    // third-party hosts entered ad hoc for scanning purposes.
    const input = endpointSchema.parse(req.body);
    const server = await prisma.server.findUnique({ where: { id: input.serverId } });
    if (!server) throw ApiError.badRequest("Endpoint must belong to a server already registered in your inventory");

    const endpoint = await prisma.endpoint.create({ data: input });
    await logActivity({ adminId: req.auth!.adminId, action: "endpoint.create", targetType: "Endpoint", targetId: endpoint.id });
    res.status(201).json({ endpoint });
  })
);

endpointsRouter.delete(
  "/:id",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    await prisma.endpoint.delete({ where: { id: req.params.id } });
    await logActivity({ adminId: req.auth!.adminId, action: "endpoint.delete", targetType: "Endpoint", targetId: req.params.id });
    res.status(204).send();
  })
);

endpointsRouter.post(
  "/:id/scan",
  asyncHandler(async (req, res) => {
    const result = await checkEndpointHealth(req.params.id);
    await logActivity({ adminId: req.auth!.adminId, action: "endpoint.scan", targetType: "Endpoint", targetId: req.params.id });
    res.json({ endpoint: result });
  })
);

endpointsRouter.post(
  "/scan-all",
  asyncHandler(async (req, res) => {
    const serverId = req.body?.serverId as string | undefined;
    const endpoints = await prisma.endpoint.findMany({ where: serverId ? { serverId } : undefined });
    const results = [];
    for (const ep of endpoints) results.push(await checkEndpointHealth(ep.id));
    res.json({ results });
  })
);
