import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";
import { generateConfiguration } from "../services/configService";
import { attemptProvisioning, attemptDeprovisioning } from "../services/vpnProvisioningService";
import { AdminRole, UserStatus } from "@prisma/client";

export const usersRouter = Router();
usersRouter.use(requireAuth);

const createUserSchema = z.object({
  username: z.string().min(3).max(64),
  serverId: z.string().min(1),
  preferredEndpointId: z.string().optional(),
  protocol: z.enum(["vless", "trojan", "wireguard"]),
  port: z.number().int().min(1).max(65535),
  tls: z.boolean().default(true),
  expiresAt: z.string().datetime().optional(),
  trafficLimitGb: z.number().positive().optional(),
  requestLimit: z.number().int().positive().optional(),
  autoIpFailover: z.boolean().default(false),
  cloudflareAccountId: z.string().optional(),
  cloudflareZoneId: z.string().optional(),
  hostname: z.string().optional(),
});

usersRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const page = Math.max(1, Number(req.query.page ?? 1));
    const pageSize = Math.min(100, Math.max(1, Number(req.query.pageSize ?? 20)));
    const search = (req.query.search as string | undefined)?.trim();
    const status = req.query.status as UserStatus | undefined;

    const where = {
      ...(search ? { username: { contains: search, mode: "insensitive" as const } } : {}),
      ...(status ? { status } : {}),
    };

    const [total, users] = await Promise.all([
      prisma.vpnUser.count({ where }),
      prisma.vpnUser.findMany({
        where,
        include: {
          server: { select: { id: true, name: true } },
          preferredEndpoint: { select: { id: true, label: true, latencyMs: true, health: true } },
        },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
    ]);

    res.json({ users, pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) } });
  })
);

usersRouter.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const user = await prisma.vpnUser.findUnique({
      where: { id: req.params.id },
      include: {
        server: true,
        configurations: { orderBy: { createdAt: "desc" }, take: 10 },
        traffic: { orderBy: { periodStart: "desc" }, take: 12 },
        requests: { orderBy: { periodStart: "desc" }, take: 12 },
      },
    });
    if (!user) throw ApiError.notFound("User not found");
    res.json({ user });
  })
);

usersRouter.post(
  "/",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const input = createUserSchema.parse(req.body);

    const existing = await prisma.vpnUser.findUnique({ where: { username: input.username } });
    if (existing) throw ApiError.conflict("A user with this username already exists");

    const user = await prisma.vpnUser.create({
      data: {
        username: input.username,
        serverId: input.serverId,
        preferredEndpointId: input.preferredEndpointId || null,
        protocol: input.protocol,
        port: input.port,
        tls: input.tls,
        expiresAt: input.expiresAt ? new Date(input.expiresAt) : null,
        trafficLimitBytes: input.trafficLimitGb ? BigInt(Math.round(input.trafficLimitGb * 1e9)) : null,
        requestLimit: input.requestLimit ?? null,
        autoIpFailover: input.autoIpFailover,
      },
    });

    let config;
    try {
      config = await generateConfiguration(user.id, {
        cloudflareAccountId: input.cloudflareAccountId,
        cloudflareZoneId: input.cloudflareZoneId,
        hostname: input.hostname,
      });
    } catch (err) {
      // Roll back the user record rather than leaving an orphaned VpnUser
      // with no configuration when Cloudflare verification fails.
      await prisma.vpnUser.delete({ where: { id: user.id } }).catch(() => undefined);
      throw err;
    }

    // Config GENERATION (above) always succeeds if the data is valid.
    // Provisioning is a separate, best-effort step against whatever
    // VpnProvider is configured (NullVpnProvider by default — see
    // providers/nullVpnProvider.ts) and never silently implied as done.
    const provisionResult = await attemptProvisioning(user.id);

    await logActivity({ adminId: req.auth!.adminId, action: "user.create", targetType: "VpnUser", targetId: user.id });

    const finalUser = await prisma.vpnUser.findUniqueOrThrow({ where: { id: user.id } });
    res.status(201).json({ user: finalUser, configuration: config, provisioning: provisionResult });
  })
);

const updateUserSchema = createUserSchema.partial().extend({
  status: z.nativeEnum(UserStatus).optional(),
});

usersRouter.patch(
  "/:id",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const input = updateUserSchema.parse(req.body);
    const user = await prisma.vpnUser.update({
      where: { id: req.params.id },
      data: {
        ...(input.serverId ? { serverId: input.serverId } : {}),
        ...(input.preferredEndpointId !== undefined ? { preferredEndpointId: input.preferredEndpointId || null } : {}),
        ...(input.protocol ? { protocol: input.protocol } : {}),
        ...(input.port ? { port: input.port } : {}),
        ...(input.tls !== undefined ? { tls: input.tls } : {}),
        ...(input.status ? { status: input.status } : {}),
        ...(input.expiresAt ? { expiresAt: new Date(input.expiresAt) } : {}),
        ...(input.trafficLimitGb ? { trafficLimitBytes: BigInt(Math.round(input.trafficLimitGb * 1e9)) } : {}),
        ...(input.requestLimit ? { requestLimit: input.requestLimit } : {}),
        ...(input.autoIpFailover !== undefined ? { autoIpFailover: input.autoIpFailover } : {}),
      },
    });
    await logActivity({ adminId: req.auth!.adminId, action: "user.update", targetType: "VpnUser", targetId: user.id });
    res.json({ user });
  })
);

usersRouter.post(
  "/:id/suspend",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const user = await prisma.vpnUser.update({ where: { id: req.params.id }, data: { status: UserStatus.SUSPENDED } });
    await logActivity({ adminId: req.auth!.adminId, action: "user.suspend", targetType: "VpnUser", targetId: user.id });
    res.json({ user });
  })
);

usersRouter.post(
  "/:id/enable",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const user = await prisma.vpnUser.update({ where: { id: req.params.id }, data: { status: UserStatus.ACTIVE } });
    await logActivity({ adminId: req.auth!.adminId, action: "user.enable", targetType: "VpnUser", targetId: user.id });
    res.json({ user });
  })
);

usersRouter.delete(
  "/:id",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    await attemptDeprovisioning(req.params.id).catch(() => undefined);
    await prisma.vpnUser.delete({ where: { id: req.params.id } });
    await logActivity({ adminId: req.auth!.adminId, action: "user.delete", targetType: "VpnUser", targetId: req.params.id });
    res.status(204).send();
  })
);

usersRouter.post(
  "/:id/provision",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const result = await attemptProvisioning(req.params.id);
    await logActivity({ adminId: req.auth!.adminId, action: "user.provision.retry", targetType: "VpnUser", targetId: req.params.id });
    res.json({ provisioning: result });
  })
);

usersRouter.post(
  "/:id/config/regenerate",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const config = await generateConfiguration(req.params.id);
    await logActivity({ adminId: req.auth!.adminId, action: "user.config.regenerate", targetType: "VpnUser", targetId: req.params.id });
    res.json({ configuration: config });
  })
);
