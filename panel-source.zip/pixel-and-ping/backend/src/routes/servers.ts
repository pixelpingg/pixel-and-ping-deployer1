import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";
import { checkEndpointHealth } from "../services/healthCheckService";
import { AdminRole, ServerStatus } from "@prisma/client";

export const serversRouter = Router();
serversRouter.use(requireAuth);

const serverSchema = z.object({
  name: z.string().min(2),
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535),
  protocol: z.string().min(2),
  location: z.string().optional(),
  cloudflareAccountId: z.string().optional(),
});

serversRouter.get(
  "/",
  asyncHandler(async (_req, res) => {
    const servers = await prisma.server.findMany({
      include: {
        _count: { select: { users: true, endpoints: true } },
      },
      orderBy: { createdAt: "desc" },
    });
    res.json({ servers });
  })
);

serversRouter.get(
  "/:id",
  asyncHandler(async (req, res) => {
    const server = await prisma.server.findUnique({
      where: { id: req.params.id },
      include: { endpoints: true, cloudflareAccount: { select: { id: true, name: true } } },
    });
    if (!server) throw ApiError.notFound("Server not found");
    res.json({ server });
  })
);

serversRouter.post(
  "/",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const input = serverSchema.parse(req.body);
    const server = await prisma.server.create({ data: input });
    await logActivity({ adminId: req.auth!.adminId, action: "server.create", targetType: "Server", targetId: server.id });
    res.status(201).json({ server });
  })
);

serversRouter.patch(
  "/:id",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const input = serverSchema.partial().parse(req.body);
    const server = await prisma.server.update({ where: { id: req.params.id }, data: input });
    await logActivity({ adminId: req.auth!.adminId, action: "server.update", targetType: "Server", targetId: server.id });
    res.json({ server });
  })
);

serversRouter.post(
  "/:id/toggle",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const server = await prisma.server.findUniqueOrThrow({ where: { id: req.params.id } });
    const updated = await prisma.server.update({ where: { id: server.id }, data: { isEnabled: !server.isEnabled } });
    await logActivity({ adminId: req.auth!.adminId, action: "server.toggle", targetType: "Server", targetId: server.id });
    res.json({ server: updated });
  })
);

serversRouter.delete(
  "/:id",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    await prisma.server.delete({ where: { id: req.params.id } });
    await logActivity({ adminId: req.auth!.adminId, action: "server.delete", targetType: "Server", targetId: req.params.id });
    res.status(204).send();
  })
);

serversRouter.post(
  "/:id/health-check",
  asyncHandler(async (req, res) => {
    const endpoints = await prisma.endpoint.findMany({ where: { serverId: req.params.id } });
    if (endpoints.length === 0) {
      throw ApiError.badRequest("This server has no endpoints configured to health-check");
    }
    const results = [];
    for (const ep of endpoints) results.push(await checkEndpointHealth(ep.id));

    const anyHealthy = results.some((r) => r.health !== "OFFLINE");
    const server = await prisma.server.findUniqueOrThrow({ where: { id: req.params.id } });
    const newStatus = anyHealthy ? ServerStatus.ONLINE : ServerStatus.OFFLINE;

    if (server.status !== ServerStatus.OFFLINE && newStatus === ServerStatus.OFFLINE) {
      const { createNotification } = await import("../services/notificationService");
      await createNotification({
        level: "ERROR",
        title: "Server offline",
        message: `${server.name} has no healthy endpoints.`,
      });
    }

    await prisma.server.update({ where: { id: req.params.id }, data: { status: newStatus } });

    res.json({ results });
  })
);
