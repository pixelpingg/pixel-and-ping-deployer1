import { Router } from "express";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { AdminRole } from "@prisma/client";

export const logsRouter = Router();
logsRouter.use(requireAuth, requireRole(AdminRole.ADMIN));

logsRouter.get(
  "/",
  asyncHandler(async (req, res) => {
    const page = Math.max(1, Number(req.query.page ?? 1));
    const pageSize = Math.min(100, Math.max(1, Number(req.query.pageSize ?? 30)));
    const action = req.query.action as string | undefined;

    const where = action ? { action: { contains: action } } : {};

    const [total, logs] = await Promise.all([
      prisma.activityLog.count({ where }),
      prisma.activityLog.findMany({
        where,
        include: { admin: { select: { username: true, email: true } } },
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
      }),
    ]);

    res.json({ logs, pagination: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) } });
  })
);
