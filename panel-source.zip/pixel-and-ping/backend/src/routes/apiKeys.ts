import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { generateApiKey, hashApiKey } from "../lib/apiKey";
import { logActivity } from "../services/activityLogService";
import { AdminRole, ApiKeyScope } from "@prisma/client";

export const apiKeysRouter = Router();
apiKeysRouter.use(requireAuth, requireRole(AdminRole.ADMIN));

const publicSelect = {
  id: true, name: true, keyPrefix: true, scopes: true, isActive: true,
  lastUsedAt: true, createdAt: true, revokedAt: true,
  createdBy: { select: { username: true } },
} as const;

apiKeysRouter.get(
  "/",
  asyncHandler(async (_req, res) => {
    const keys = await prisma.apiKey.findMany({ select: publicSelect, orderBy: { createdAt: "desc" } });
    res.json({ keys });
  })
);

const createSchema = z.object({
  name: z.string().min(2).max(64),
  scopes: z.array(z.nativeEnum(ApiKeyScope)).min(1),
});

apiKeysRouter.post(
  "/",
  asyncHandler(async (req, res) => {
    const input = createSchema.parse(req.body);
    const { plaintext, prefix } = generateApiKey();
    const keyHash = await hashApiKey(plaintext);

    const key = await prisma.apiKey.create({
      data: { name: input.name, scopes: input.scopes, keyPrefix: prefix, keyHash, createdById: req.auth!.adminId },
      select: publicSelect,
    });

    await logActivity({ adminId: req.auth!.adminId, action: "apikey.create", targetType: "ApiKey", targetId: key.id });

    // The only moment the plaintext key ever exists outside this function's
    // stack — returned once, never retrievable again, never logged.
    res.status(201).json({ key, plaintextKey: plaintext });
  })
);

apiKeysRouter.post(
  "/:id/revoke",
  asyncHandler(async (req, res) => {
    const key = await prisma.apiKey.update({
      where: { id: req.params.id },
      data: { isActive: false, revokedAt: new Date() },
      select: publicSelect,
    });
    await logActivity({ adminId: req.auth!.adminId, action: "apikey.revoke", targetType: "ApiKey", targetId: key.id });
    res.json({ key });
  })
);

apiKeysRouter.delete(
  "/:id",
  asyncHandler(async (req, res) => {
    await prisma.apiKey.delete({ where: { id: req.params.id } });
    await logActivity({ adminId: req.auth!.adminId, action: "apikey.delete", targetType: "ApiKey", targetId: req.params.id });
    res.status(204).send();
  })
);
