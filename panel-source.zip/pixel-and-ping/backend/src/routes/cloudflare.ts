import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";
import * as cf from "../services/cloudflareService";
import { AdminRole } from "@prisma/client";

export const cloudflareRouter = Router();
cloudflareRouter.use(requireAuth);

// Never select encryptedToken/tokenIv/tokenAuthTag in any response.
const publicAccountSelect = {
  id: true,
  name: true,
  accountId: true,
  isActive: true,
  status: true,
  lastSyncAt: true,
  lastSyncError: true,
  createdAt: true,
} as const;

cloudflareRouter.get(
  "/accounts",
  asyncHandler(async (_req, res) => {
    const accounts = await prisma.cloudflareAccount.findMany({
      select: publicAccountSelect,
      orderBy: { createdAt: "desc" },
    });
    res.json({ accounts });
  })
);

// .trim(): a stray leading/trailing space or newline from copy-pasting the
// token out of the Cloudflare dashboard still passes min-length validation
// but produces a malformed Authorization header, which Cloudflare rejects —
// surfacing as a clearly-valid token being reported as unverifiable.
const addAccountSchema = z.object({
  name: z.string().min(2).transform((v) => v.trim()),
  accountId: z.string().min(4).transform((v) => v.trim()),
  apiToken: z.string().min(10).transform((v) => v.trim()),
});

cloudflareRouter.post(
  "/accounts",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const input = addAccountSchema.parse(req.body);
    const account = await cf.addCloudflareAccount(input);
    await logActivity({ adminId: req.auth!.adminId, action: "cloudflare.account.add", targetType: "CloudflareAccount", targetId: account.id });
    const { encryptedToken, tokenIv, tokenAuthTag, ...safe } = account;
    res.status(201).json({ account: safe });
  })
);

cloudflareRouter.post(
  "/accounts/:id/test",
  asyncHandler(async (req, res) => {
    const result = await cf.testConnection(req.params.id);
    res.json(result);
  })
);

cloudflareRouter.post(
  "/accounts/:id/toggle",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const account = await prisma.cloudflareAccount.findUniqueOrThrow({ where: { id: req.params.id } });
    const updated = await prisma.cloudflareAccount.update({
      where: { id: account.id },
      data: { isActive: !account.isActive },
      select: publicAccountSelect,
    });
    await logActivity({ adminId: req.auth!.adminId, action: "cloudflare.account.toggle", targetType: "CloudflareAccount", targetId: account.id });
    res.json({ account: updated });
  })
);

cloudflareRouter.delete(
  "/accounts/:id",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    await prisma.cloudflareAccount.delete({ where: { id: req.params.id } });
    await logActivity({ adminId: req.auth!.adminId, action: "cloudflare.account.remove", targetType: "CloudflareAccount", targetId: req.params.id });
    res.status(204).send();
  })
);

cloudflareRouter.get(
  "/accounts/:id/zones",
  asyncHandler(async (req, res) => {
    const zones = await cf.listZones(req.params.id);
    res.json({ zones });
  })
);

cloudflareRouter.get(
  "/accounts/:id/workers",
  asyncHandler(async (req, res) => {
    const workers = await cf.listWorkers(req.params.id);
    if (workers === null) {
      return res.json({ workers: null, message: "Unavailable from Cloudflare API" });
    }
    res.json({ workers });
  })
);

cloudflareRouter.get(
  "/accounts/:id/usage",
  asyncHandler(async (req, res) => {
    const snapshots = await prisma.cloudflareUsageSnapshot.findMany({
      where: { accountId: req.params.id },
      orderBy: { capturedAt: "desc" },
      take: 90,
    });
    res.json({
      snapshots: snapshots.map((s) => ({ ...s, bandwidthBytes: s.bandwidthBytes?.toString() ?? null })),
    });
  })
);

// Per-zone breakdown of the most recent snapshot for each zone the account
// has synced — every row carries its own `source` and `dataAvailable` so
// the UI never has to guess whether a number is real.
cloudflareRouter.get(
  "/accounts/:id/usage/by-zone",
  asyncHandler(async (req, res) => {
    const recent = await prisma.cloudflareUsageSnapshot.findMany({
      where: { accountId: req.params.id, zoneId: { not: null } },
      orderBy: { capturedAt: "desc" },
      take: 200,
    });
    const latestByZone = new Map<string, (typeof recent)[number]>();
    for (const s of recent) {
      if (s.zoneId && !latestByZone.has(s.zoneId)) latestByZone.set(s.zoneId, s);
    }
    res.json({
      zones: [...latestByZone.values()].map((s) => ({
        zoneId: s.zoneId,
        zoneName: s.zoneName,
        requestsToday: s.requestsToday,
        bandwidthBytes: s.bandwidthBytes?.toString() ?? null,
        dataAvailable: s.dataAvailable,
        source: s.source,
        capturedAt: s.capturedAt,
      })),
    });
  })
);

cloudflareRouter.post(
  "/sync",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    await cf.syncAllCloudflareAccounts();
    await logActivity({ adminId: req.auth!.adminId, action: "cloudflare.sync" });
    res.json({ ok: true });
  })
);
