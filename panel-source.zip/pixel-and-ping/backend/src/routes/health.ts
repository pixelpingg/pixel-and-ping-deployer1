import { Router } from "express";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth } from "../middleware/auth";
import { checkAllEndpoints } from "../services/healthCheckService";

export const healthRouter = Router();
healthRouter.use(requireAuth);

healthRouter.get(
  "/endpoints",
  asyncHandler(async (req, res) => {
    const sortBy = (req.query.sortBy as string | undefined) ?? "score";
    const order = (req.query.order as "asc" | "desc" | undefined) ?? "desc";
    const health = req.query.health as string | undefined;

    const endpoints = await prisma.endpoint.findMany({
      where: health ? { health: health as any } : undefined,
      orderBy: { [sortBy]: order } as any,
      include: { server: { select: { id: true, name: true } } },
    });
    res.json({ endpoints });
  })
);

healthRouter.post(
  "/scan-all",
  asyncHandler(async (_req, res) => {
    const results = await checkAllEndpoints();
    res.json({ results });
  })
);

healthRouter.get(
  "/history/:endpointId",
  asyncHandler(async (req, res) => {
    const history = await prisma.healthCheck.findMany({
      where: { endpointId: req.params.endpointId },
      orderBy: { checkedAt: "desc" },
      take: 50,
    });
    res.json({ history });
  })
);
