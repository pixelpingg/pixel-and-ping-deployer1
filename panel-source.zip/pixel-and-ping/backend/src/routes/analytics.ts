import { Router } from "express";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth } from "../middleware/auth";
import { UserStatus } from "@prisma/client";

export const analyticsRouter = Router();
analyticsRouter.use(requireAuth);

// Powers the Dashboard's stat cards — every figure is a real DB
// aggregate. Nothing here is randomly generated.
analyticsRouter.get(
  "/dashboard",
  asyncHandler(async (_req, res) => {
    const [
      totalUsers,
      activeUsers,
      onlineUsers,
      activeServers,
      totalServers,
      cloudflareAccounts,
      healthyEndpoints,
      totalEndpoints,
      recentZoneSnapshots,
    ] = await Promise.all([
      prisma.vpnUser.count(),
      prisma.vpnUser.count({ where: { status: UserStatus.ACTIVE } }),
      prisma.vpnUser.count({ where: { isOnline: true } }),
      prisma.server.count({ where: { isEnabled: true, status: "ONLINE" } }),
      prisma.server.count(),
      prisma.cloudflareAccount.count({ where: { isActive: true } }),
      prisma.endpoint.count({ where: { health: { in: ["EXCELLENT", "GOOD", "FAIR"] } } }),
      prisma.endpoint.count(),
      prisma.cloudflareUsageSnapshot.findMany({
        where: { zoneId: { not: null } },
        orderBy: { capturedAt: "desc" },
        take: 200,
      }),
    ]);

    const trafficAgg = await prisma.trafficUsage.aggregate({
      _sum: { uploadBytes: true, downloadBytes: true },
    });

    // Sum the latest snapshot per zone rather than a single arbitrary row —
    // an account/panel can have many zones, and requests must be added
    // across them, not overwritten by whichever synced most recently.
    const latestByZone = new Map<string, (typeof recentZoneSnapshots)[number]>();
    for (const s of recentZoneSnapshots) {
      if (s.zoneId && !latestByZone.has(s.zoneId)) latestByZone.set(s.zoneId, s);
    }
    const zoneSnapshots = [...latestByZone.values()];
    const availableZoneSnapshots = zoneSnapshots.filter((s) => s.dataAvailable);
    const dailyRequestsAvailable = availableZoneSnapshots.length > 0;
    const dailyRequests = dailyRequestsAvailable
      ? availableZoneSnapshots.reduce((sum, s) => sum + (s.requestsToday ?? 0), 0)
      : null;

    res.json({
      totalUsers,
      activeUsers,
      onlineUsers,
      activeServers,
      totalServers,
      cloudflareAccounts,
      healthyEndpoints,
      totalEndpoints,
      totalTrafficBytes: (
        (trafficAgg._sum.uploadBytes ?? 0n) + (trafficAgg._sum.downloadBytes ?? 0n)
      ).toString(),
      dailyRequests,
      dailyRequestsAvailable,
    });
  })
);

analyticsRouter.get(
  "/traffic-series",
  asyncHandler(async (_req, res) => {
    const rows = await prisma.trafficUsage.findMany({
      orderBy: { periodStart: "asc" },
      take: 90,
    });
    res.json({
      series: rows.map((r) => ({
        date: r.periodStart,
        upload: Number(r.uploadBytes),
        download: Number(r.downloadBytes),
        isEstimated: r.isEstimated,
      })),
    });
  })
);

analyticsRouter.get(
  "/user-activity",
  asyncHandler(async (_req, res) => {
    const counts = await prisma.vpnUser.groupBy({ by: ["status"], _count: { status: true } });
    const online = await prisma.vpnUser.count({ where: { isOnline: true } });
    const offline = await prisma.vpnUser.count({ where: { isOnline: false } });
    res.json({
      byStatus: counts.map((c) => ({ status: c.status, count: c._count.status })),
      online,
      offline,
    });
  })
);

// Aggregated Cloudflare usage across every connected account/zone, for the
// Traffic/Analytics pages. Every number here traces back to a real
// CloudflareUsageSnapshot row created by services/cloudflareService.ts's
// sync job — nothing is computed or estimated here.
//
// range=today (default): latest snapshot per zone.
// range=7d / range=30d: sums one representative (latest-of-day) snapshot
// per zone per calendar day across the window — never raw snapshot counts,
// since the sync job can capture a zone many times a day and Cloudflare's
// httpRequests1dGroups query is itself a rolling last-24h figure, not a
// per-sync delta.
analyticsRouter.get(
  "/cloudflare-usage",
  asyncHandler(async (req, res) => {
    const range = (req.query.range as string | undefined) ?? "today";
    const windowDays = range === "30d" ? 30 : range === "7d" ? 7 : 1;

    const accounts = await prisma.cloudflareAccount.findMany({ where: { isActive: true } });
    if (accounts.length === 0) {
      return res.json({ available: false, reason: "No active Cloudflare accounts connected", zones: [], range });
    }

    const since = new Date(Date.now() - windowDays * 24 * 60 * 60 * 1000);
    const recent = await prisma.cloudflareUsageSnapshot.findMany({
      where: { accountId: { in: accounts.map((a) => a.id) }, zoneId: { not: null }, capturedAt: { gte: since } },
      orderBy: { capturedAt: "desc" },
      take: 5000,
    });

    if (recent.length === 0) {
      return res.json({ available: false, reason: "No Cloudflare analytics have synced yet in this window", zones: [], range });
    }

    // One representative snapshot per (zone, calendar day) — the latest
    // sync of that day, since Cloudflare's rolling-24h figure is most
    // complete right before the day rolls over.
    const byZoneDay = new Map<string, (typeof recent)[number]>();
    for (const s of recent) {
      const day = s.capturedAt.toISOString().slice(0, 10);
      const key = `${s.zoneId}:${day}`;
      if (!byZoneDay.has(key)) byZoneDay.set(key, s);
    }
    const dayRows = [...byZoneDay.values()];

    const zoneNames = new Map<string, string>();
    for (const s of dayRows) if (s.zoneId && s.zoneName) zoneNames.set(s.zoneId, s.zoneName);

    const zoneTotals = new Map<string, { requests: number; bytes: bigint; anyAvailable: boolean; anyUnavailable: boolean; latestCapturedAt: Date; source: string }>();
    for (const s of dayRows) {
      if (!s.zoneId) continue;
      const existing = zoneTotals.get(s.zoneId) ?? { requests: 0, bytes: 0n, anyAvailable: false, anyUnavailable: false, latestCapturedAt: s.capturedAt, source: s.source };
      if (s.dataAvailable) {
        existing.requests += s.requestsToday ?? 0;
        existing.bytes += s.bandwidthBytes ?? 0n;
        existing.anyAvailable = true;
      } else {
        existing.anyUnavailable = true;
      }
      if (s.capturedAt > existing.latestCapturedAt) {
        existing.latestCapturedAt = s.capturedAt;
        existing.source = s.source;
      }
      zoneTotals.set(s.zoneId, existing);
    }

    const zones = [...zoneTotals.entries()].map(([zoneId, v]) => ({
      zoneId,
      zoneName: zoneNames.get(zoneId) ?? zoneId,
      requestsToday: v.anyAvailable ? v.requests : null,
      bandwidthBytes: v.anyAvailable ? v.bytes.toString() : null,
      dataAvailable: v.anyAvailable,
      partiallyAvailable: v.anyAvailable && v.anyUnavailable,
      source: v.anyAvailable ? v.source : "Unavailable from Cloudflare API",
      capturedAt: v.latestCapturedAt,
    }));

    const availableZones = zones.filter((z) => z.dataAvailable);

    res.json({
      available: availableZones.length > 0,
      range,
      totalRequestsToday: availableZones.reduce((sum, z) => sum + (z.requestsToday ?? 0), 0),
      totalBandwidthBytes: availableZones
        .reduce((sum, z) => sum + BigInt(z.bandwidthBytes ?? "0"), 0n)
        .toString(),
      zones,
    });
  })
);

// Per-server latency/health rollup for the Dashboard and Analytics pages'
// "avgLatencyMs" bar chart — mirrors worker/src/routes/analytics.ts's
// GET /server-health exactly, so both backends serve the same contract.
analyticsRouter.get(
  "/server-health",
  asyncHandler(async (_req, res) => {
    const servers = await prisma.server.findMany({
      include: { endpoints: { select: { latencyMs: true, health: true } } },
    });
    res.json({
      servers: servers.map((s) => ({
        id: s.id,
        name: s.name,
        status: s.status,
        avgLatencyMs:
          s.endpoints.filter((e) => e.latencyMs !== null).length > 0
            ? Math.round(
                s.endpoints.reduce((sum, e) => sum + (e.latencyMs ?? 0), 0) /
                  s.endpoints.filter((e) => e.latencyMs !== null).length
              )
            : null,
        endpointHealth: s.endpoints.map((e) => e.health),
      })),
    });
  })
);
