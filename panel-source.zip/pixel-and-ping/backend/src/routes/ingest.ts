import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { asyncHandler } from "../middleware/errorHandler";
import { requireApiKey } from "../middleware/apiKeyAuth";
import { trafficProvider, presenceProvider } from "../providers";
import { ApiKeyScope } from "@prisma/client";

/**
 * ===========================================================================
 * INGESTION API — for authorized external services only (a VPN daemon, a
 * metering sidecar). This is the "real data in" side of traffic accounting
 * and presence described in README.md#real-vpn-deployment. Nothing on the
 * frontend calls these routes; they exist for your VPN infrastructure to
 * call directly, authenticated with a long-lived API key (see
 * routes/apiKeys.ts for issuing one), not an admin session cookie.
 * ===========================================================================
 */
export const ingestRouter = Router();

// Ingestion is machine-to-machine and potentially high frequency (one
// heartbeat per connected user every 30-60s is a reasonable daemon
// interval) — a higher, separate limit from the interactive admin API.
const ingestRateLimiter = rateLimit({
  windowMs: 60_000,
  max: 600,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: { code: "TOO_MANY_REQUESTS", message: "Ingestion rate limit exceeded" } },
});
ingestRouter.use(ingestRateLimiter);

async function resolveUser(input: { userId?: string; username?: string }) {
  if (input.userId) {
    const user = await prisma.vpnUser.findUnique({ where: { id: input.userId } });
    if (!user) throw ApiError.notFound("Unknown userId");
    return user;
  }
  if (input.username) {
    const user = await prisma.vpnUser.findUnique({ where: { username: input.username } });
    if (!user) throw ApiError.notFound("Unknown username");
    return user;
  }
  throw ApiError.badRequest("Provide either userId or username");
}

/**
 * POST /api/ingest/traffic
 *
 * Auth:      Authorization: Bearer <api key with TRAFFIC_INGEST or FULL_INGEST scope>
 * Request:   {
 *              userId?: string, username?: string,      // one required
 *              uploadBytes: number | string,             // bytes, this reporting period
 *              downloadBytes: number | string,
 *              periodStart: string (ISO 8601),
 *              periodEnd: string (ISO 8601),
 *              requestCount?: number,                     // optional, if the daemon can count requests
 *              isEstimated?: boolean,                      // default true — set false only if the figure
 *                                                            // comes from an authoritative meter
 *              idempotencyKey?: string                      // strongly recommended: daemon-generated,
 *                                                            // unique per (user, period) report
 *            }
 * Response:  { traffic: { created: boolean, id: string }, requests?: { created: boolean, id: string } }
 *
 * DB effect: Inserts one TrafficUsage row (and one RequestUsage row if
 *            requestCount is given). If idempotencyKey matches an existing
 *            row, no new row is created and the existing id is returned —
 *            safe to retry on daemon-side network failure. Also
 *            auto-suspends the user if trafficLimitBytes/requestLimit is
 *            now exceeded.
 */
const trafficIngestSchema = z.object({
  userId: z.string().optional(),
  username: z.string().optional(),
  uploadBytes: z.union([z.number(), z.string()]),
  downloadBytes: z.union([z.number(), z.string()]),
  periodStart: z.string().datetime(),
  periodEnd: z.string().datetime(),
  requestCount: z.number().int().nonnegative().optional(),
  isEstimated: z.boolean().default(true),
  idempotencyKey: z.string().max(128).optional(),
});

ingestRouter.post(
  "/traffic",
  requireApiKey(ApiKeyScope.TRAFFIC_INGEST, ApiKeyScope.FULL_INGEST),
  asyncHandler(async (req, res) => {
    const input = trafficIngestSchema.parse(req.body);
    const user = await resolveUser(input);

    const traffic = await trafficProvider.recordTraffic({
      userId: user.id,
      uploadBytes: BigInt(input.uploadBytes),
      downloadBytes: BigInt(input.downloadBytes),
      periodStart: new Date(input.periodStart),
      periodEnd: new Date(input.periodEnd),
      isEstimated: input.isEstimated,
      sourceApiKeyId: req.apiKey!.id,
      idempotencyKey: input.idempotencyKey,
    });

    let requests: { created: boolean; id: string } | undefined;
    if (input.requestCount !== undefined) {
      requests = await trafficProvider.recordRequests({
        userId: user.id,
        count: input.requestCount,
        periodStart: new Date(input.periodStart),
        periodEnd: new Date(input.periodEnd),
        idempotencyKey: input.idempotencyKey ? `${input.idempotencyKey}:requests` : undefined,
      });
    }

    res.status(traffic.created ? 201 : 200).json({ traffic, requests });
  })
);

/**
 * POST /api/ingest/heartbeat
 *
 * Auth:      Authorization: Bearer <api key with PRESENCE_INGEST or FULL_INGEST scope>
 * Request:   {
 *              userId?: string, username?: string,        // one required
 *              serverId?: string, endpointId?: string,      // which server/endpoint they're connected through
 *              clientIp?: string,
 *              connectionSessionId?: string                  // omit on first heartbeat of a new connection;
 *                                                             // include on subsequent heartbeats to keep the
 *                                                             // same ConnectionSession alive
 *            }
 * Response:  { connectionSessionId: string }
 *
 * DB effect: Opens or refreshes a ConnectionSession row, sets
 *            VpnUser.isOnline = true and lastSeenAt = now. Call this
 *            every 30-60s per connected user from your daemon. If no
 *            heartbeat arrives within PRESENCE_TIMEOUT_SEC (default 90s,
 *            see .env), the scheduled cleanup job marks the user offline
 *            and closes the session with endReason "heartbeat_timeout".
 */
const heartbeatSchema = z.object({
  userId: z.string().optional(),
  username: z.string().optional(),
  serverId: z.string().optional(),
  endpointId: z.string().optional(),
  clientIp: z.string().optional(),
  connectionSessionId: z.string().optional(),
});

ingestRouter.post(
  "/heartbeat",
  requireApiKey(ApiKeyScope.PRESENCE_INGEST, ApiKeyScope.FULL_INGEST),
  asyncHandler(async (req, res) => {
    const input = heartbeatSchema.parse(req.body);
    const user = await resolveUser(input);

    const result = await presenceProvider.heartbeat({
      userId: user.id,
      serverId: input.serverId,
      endpointId: input.endpointId,
      clientIp: input.clientIp,
      connectionSessionId: input.connectionSessionId,
    });

    res.json(result);
  })
);

/**
 * POST /api/ingest/session/end
 *
 * Auth:      Authorization: Bearer <api key with PRESENCE_INGEST or FULL_INGEST scope>
 * Request:   { connectionSessionId: string, reason?: string }
 * Response:  { ok: true }
 *
 * DB effect: Closes the ConnectionSession (sets endedAt), and if the user
 *            has no other open sessions, sets VpnUser.isOnline = false
 *            immediately rather than waiting for the timeout. Call this
 *            when your daemon observes a clean client disconnect.
 */
const endSessionSchema = z.object({
  connectionSessionId: z.string().min(1),
  reason: z.string().max(64).default("client_disconnect"),
});

ingestRouter.post(
  "/session/end",
  requireApiKey(ApiKeyScope.PRESENCE_INGEST, ApiKeyScope.FULL_INGEST),
  asyncHandler(async (req, res) => {
    const input = endSessionSchema.parse(req.body);
    await presenceProvider.endSession(input.connectionSessionId, input.reason);
    res.json({ ok: true });
  })
);

// Read-only diagnostic so a daemon operator can sanity-check the key
// without needing the admin panel.
ingestRouter.get(
  "/ping",
  requireApiKey(),
  asyncHandler(async (req, res) => {
    res.json({ ok: true, scopes: req.apiKey!.scopes });
  })
);
