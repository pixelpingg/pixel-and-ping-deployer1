import { Router } from "express";
import net from "net";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";
import { AdminRole, PortType } from "@prisma/client";

export const portsRouter = Router();
portsRouter.use(requireAuth);

export const WELL_KNOWN_TLS_PORTS = [443, 8443, 2053, 2083, 2087, 2096];
export const WELL_KNOWN_NON_TLS_PORTS = [80, 8080, 2052, 2082, 2086, 2095];

portsRouter.get(
  "/",
  asyncHandler(async (_req, res) => {
    const ports = await prisma.port.findMany({ orderBy: { number: "asc" } });
    res.json({
      ports,
      presets: { tls: WELL_KNOWN_TLS_PORTS, nonTls: WELL_KNOWN_NON_TLS_PORTS },
    });
  })
);

const createPortSchema = z.object({
  number: z.number().int().min(1).max(65535),
  type: z.nativeEnum(PortType),
  label: z.string().optional(),
});

// Confirms the port can actually be bound locally before it's ever marked
// active. This is a same-host bind test, not a scan of third-party hosts.
async function canBindLocally(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once("error", () => resolve(false));
    server.once("listening", () => {
      server.close(() => resolve(true));
    });
    server.listen(port, "0.0.0.0");
  });
}

portsRouter.post(
  "/",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const input = createPortSchema.parse(req.body);

    if (input.number < 1 || input.number > 65535) {
      throw ApiError.badRequest("Port number must be between 1 and 65535");
    }

    const existing = await prisma.port.findUnique({ where: { number: input.number } });
    if (existing) throw ApiError.conflict("This port is already registered");

    const port = await prisma.port.create({
      data: { number: input.number, type: input.type, label: input.label, isActive: false },
    });

    await logActivity({ adminId: req.auth!.adminId, action: "port.create", targetType: "Port", targetId: port.id });
    res.status(201).json({ port });
  })
);

portsRouter.post(
  "/:id/validate",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const port = await prisma.port.findUniqueOrThrow({ where: { id: req.params.id } });
    const bindable = await canBindLocally(port.number);

    const updated = await prisma.port.update({
      where: { id: port.id },
      data: { isActive: bindable, lastCheckedAt: new Date() },
    });

    await logActivity({ adminId: req.auth!.adminId, action: "port.validate", targetType: "Port", targetId: port.id, metadata: { bindable } });
    res.json({ port: updated, bindable });
  })
);

portsRouter.delete(
  "/:id",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    await prisma.port.delete({ where: { id: req.params.id } });
    await logActivity({ adminId: req.auth!.adminId, action: "port.delete", targetType: "Port", targetId: req.params.id });
    res.status(204).send();
  })
);
