import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";
import { AdminRole } from "@prisma/client";

export const settingsRouter = Router();
settingsRouter.use(requireAuth);

settingsRouter.get(
  "/",
  asyncHandler(async (_req, res) => {
    const settings = await prisma.setting.findMany();
    const map = Object.fromEntries(settings.map((s) => [s.key, s.value]));
    res.json({ settings: map });
  })
);

const upsertSchema = z.object({ key: z.string().min(1), value: z.any() });

settingsRouter.put(
  "/:key",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const { value } = upsertSchema.parse({ key: req.params.key, value: req.body.value });
    const setting = await prisma.setting.upsert({
      where: { key: req.params.key },
      update: { value },
      create: { key: req.params.key, value },
    });
    await logActivity({ adminId: req.auth!.adminId, action: "settings.update", metadata: { key: req.params.key } });
    res.json({ setting });
  })
);
