import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";
import { evaluateFailoverForAllServers } from "../services/failoverService";
import { AdminRole, LoadBalanceStrategy } from "@prisma/client";

export const failoverRouter = Router();
failoverRouter.use(requireAuth);

failoverRouter.get(
  "/settings",
  asyncHandler(async (_req, res) => {
    let settings = await prisma.failoverSettings.findFirst();
    if (!settings) {
      settings = await prisma.failoverSettings.create({ data: {} });
    }
    res.json({ settings });
  })
);

const settingsSchema = z.object({
  enabled: z.boolean().optional(),
  failureThreshold: z.number().int().min(1).max(20).optional(),
  retryCount: z.number().int().min(0).max(10).optional(),
  healthCheckIntervalSec: z.number().int().min(5).max(3600).optional(),
  recoveryThreshold: z.number().int().min(1).max(20).optional(),
  strategy: z.nativeEnum(LoadBalanceStrategy).optional(),
});

failoverRouter.patch(
  "/settings",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const input = settingsSchema.parse(req.body);
    let settings = await prisma.failoverSettings.findFirst();
    settings = settings
      ? await prisma.failoverSettings.update({ where: { id: settings.id }, data: input })
      : await prisma.failoverSettings.create({ data: input });
    await logActivity({ adminId: req.auth!.adminId, action: "failover.settings.update", metadata: input });
    res.json({ settings });
  })
);

failoverRouter.get(
  "/events",
  asyncHandler(async (_req, res) => {
    const events = await prisma.failoverEvent.findMany({
      orderBy: { triggeredAt: "desc" },
      take: 50,
      include: { fromEndpoint: true, toEndpoint: true },
    });
    res.json({ events });
  })
);

failoverRouter.post(
  "/evaluate",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (_req, res) => {
    const results = await evaluateFailoverForAllServers();
    res.json({ results });
  })
);
