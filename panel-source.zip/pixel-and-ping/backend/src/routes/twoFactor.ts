import { Router } from "express";
import { authenticator } from "otplib";
import qrcode from "qrcode";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth } from "../middleware/auth";
import { logActivity } from "../services/activityLogService";

export const twoFactorRouter = Router();
twoFactorRouter.use(requireAuth);

/**
 * POST /api/auth/2fa/setup
 * Generates a new TOTP secret and stores it as *pending* — it is not used
 * for login until /verify confirms the admin can actually produce a valid
 * code with it. Returns the otpauth:// URI (for the frontend to render as
 * a QR code) and the raw secret (for manual entry) — this is the one and
 * only time the secret is transmitted; it is never logged.
 */
twoFactorRouter.post(
  "/setup",
  asyncHandler(async (req, res) => {
    const admin = await prisma.admin.findUniqueOrThrow({ where: { id: req.auth!.adminId } });
    if (admin.twoFactorEnabled) throw ApiError.conflict("2FA is already enabled. Disable it before re-enrolling.");

    const secret = authenticator.generateSecret();
    await prisma.admin.update({ where: { id: admin.id }, data: { twoFactorPendingSecret: secret } });

    const otpauth = authenticator.keyuri(admin.email, "Pixel & Ping", secret);
    const qrDataUrl = await qrcode.toDataURL(otpauth);

    await logActivity({ adminId: admin.id, action: "2fa.setup.start" });

    res.json({ secret, otpauth, qrDataUrl });
  })
);

const verifySchema = z.object({ totpCode: z.string().min(6).max(6) });

/**
 * POST /api/auth/2fa/verify
 * Confirms the pending secret with a real TOTP code, activates 2FA, and
 * issues one-time recovery codes (shown once, stored only as bcrypt hashes).
 */
twoFactorRouter.post(
  "/verify",
  asyncHandler(async (req, res) => {
    const { totpCode } = verifySchema.parse(req.body);
    const admin = await prisma.admin.findUniqueOrThrow({ where: { id: req.auth!.adminId } });

    if (!admin.twoFactorPendingSecret) {
      throw ApiError.badRequest("No pending 2FA setup. Call /2fa/setup first.");
    }
    const valid = authenticator.check(totpCode, admin.twoFactorPendingSecret);
    if (!valid) throw ApiError.unauthorized("Invalid verification code");

    const recoveryCodes = Array.from({ length: 8 }, () => crypto.randomBytes(5).toString("hex"));
    const hashedCodes = await Promise.all(recoveryCodes.map((c) => bcrypt.hash(c, 10)));

    await prisma.$transaction([
      prisma.admin.update({
        where: { id: admin.id },
        data: { twoFactorSecret: admin.twoFactorPendingSecret, twoFactorPendingSecret: null, twoFactorEnabled: true },
      }),
      prisma.twoFactorRecoveryCode.deleteMany({ where: { adminId: admin.id } }),
      ...hashedCodes.map((codeHash) =>
        prisma.twoFactorRecoveryCode.create({ data: { adminId: admin.id, codeHash } })
      ),
    ]);

    await logActivity({ adminId: admin.id, action: "2fa.enabled" });

    // Recovery codes are plaintext exactly once, in this response.
    res.json({ enabled: true, recoveryCodes });
  })
);

const disableSchema = z.object({ password: z.string().min(1) });

/**
 * POST /api/auth/2fa/disable
 * Requires the admin's current password as a step-up confirmation before
 * turning off 2FA, so a hijacked session cookie alone can't disable it.
 */
twoFactorRouter.post(
  "/disable",
  asyncHandler(async (req, res) => {
    const { password } = disableSchema.parse(req.body);
    const admin = await prisma.admin.findUniqueOrThrow({ where: { id: req.auth!.adminId } });

    const valid = await bcrypt.compare(password, admin.passwordHash);
    if (!valid) throw ApiError.unauthorized("Incorrect password");

    await prisma.$transaction([
      prisma.admin.update({
        where: { id: admin.id },
        data: { twoFactorEnabled: false, twoFactorSecret: null, twoFactorPendingSecret: null },
      }),
      prisma.twoFactorRecoveryCode.deleteMany({ where: { adminId: admin.id } }),
    ]);

    await logActivity({ adminId: admin.id, action: "2fa.disabled" });
    res.json({ enabled: false });
  })
);

/**
 * GET /api/auth/2fa/status
 * Never returns the secret itself — only whether 2FA is on and how many
 * unused recovery codes remain.
 */
twoFactorRouter.get(
  "/status",
  asyncHandler(async (req, res) => {
    const admin = await prisma.admin.findUniqueOrThrow({ where: { id: req.auth!.adminId } });
    const remainingCodes = await prisma.twoFactorRecoveryCode.count({
      where: { adminId: admin.id, usedAt: null },
    });
    res.json({ enabled: admin.twoFactorEnabled, remainingRecoveryCodes: remainingCodes });
  })
);
