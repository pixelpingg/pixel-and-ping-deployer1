import { Router } from "express";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth } from "../middleware/auth";

export const trafficRouter = Router();
trafficRouter.use(requireAuth);

trafficRouter.get(
  "/summary",
  asyncHandler(async (_req, res) => {
    const rows = await prisma.trafficUsage.findMany({
      orderBy: { periodStart: "desc" },
      take: 500,
    });

    const totalUpload = rows.reduce((sum, r) => sum + r.uploadBytes, 0n);
    const totalDownload = rows.reduce((sum, r) => sum + r.downloadBytes, 0n);
    const anyEstimated = rows.some((r) => r.isEstimated);

    res.json({
      totalUploadBytes: totalUpload.toString(),
      totalDownloadBytes: totalDownload.toString(),
      totalBytes: (totalUpload + totalDownload).toString(),
      isEstimated: anyEstimated,
      sampleSize: rows.length,
    });
  })
);

trafficRouter.get(
  "/user/:userId",
  asyncHandler(async (req, res) => {
    const rows = await prisma.trafficUsage.findMany({
      where: { userId: req.params.userId },
      orderBy: { periodStart: "desc" },
      take: 30,
    });
    res.json({
      usage: rows.map((r) => ({
        ...r,
        uploadBytes: r.uploadBytes.toString(),
        downloadBytes: r.downloadBytes.toString(),
      })),
    });
  })
);

trafficRouter.get(
  "/server/:serverId",
  asyncHandler(async (req, res) => {
    const users = await prisma.vpnUser.findMany({ where: { serverId: req.params.serverId }, select: { id: true } });
    const userIds = users.map((u) => u.id);
    const rows = await prisma.trafficUsage.findMany({
      where: { userId: { in: userIds } },
      orderBy: { periodStart: "desc" },
      take: 200,
    });
    const totalUpload = rows.reduce((sum, r) => sum + r.uploadBytes, 0n);
    const totalDownload = rows.reduce((sum, r) => sum + r.downloadBytes, 0n);
    res.json({
      totalUploadBytes: totalUpload.toString(),
      totalDownloadBytes: totalDownload.toString(),
      isEstimated: rows.some((r) => r.isEstimated),
    });
  })
);
