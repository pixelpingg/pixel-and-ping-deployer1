import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { asyncHandler } from "../middleware/errorHandler";
import { requireAuth, requireRole } from "../middleware/auth";
import { generateConfiguration, revokeConfiguration } from "../services/configService";
import { logActivity } from "../services/activityLogService";
import { AdminRole } from "@prisma/client";

export const configsRouter = Router();
configsRouter.use(requireAuth);

configsRouter.get(
  "/user/:userId",
  asyncHandler(async (req, res) => {
    const configs = await prisma.configuration.findMany({
      where: { userId: req.params.userId },
      orderBy: { createdAt: "desc" },
    });
    res.json({ configurations: configs });
  })
);

const generateOptionsSchema = z.object({
  cloudflareAccountId: z.string().optional(),
  cloudflareZoneId: z.string().optional(),
  hostname: z.string().optional(),
});

configsRouter.post(
  "/user/:userId/generate",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const options = generateOptionsSchema.parse(req.body ?? {});
    const config = await generateConfiguration(req.params.userId, options);
    await logActivity({ adminId: req.auth!.adminId, action: "config.generate", targetType: "Configuration", targetId: config.id });
    res.status(201).json({ configuration: config });
  })
);

configsRouter.post(
  "/:id/revoke",
  requireRole(AdminRole.ADMIN),
  asyncHandler(async (req, res) => {
    const config = await revokeConfiguration(req.params.id);
    await logActivity({ adminId: req.auth!.adminId, action: "config.revoke", targetType: "Configuration", targetId: config.id });
    res.json({ configuration: config });
  })
);
