import { VpnProvider, VpnProvisionResult } from "./types";
import { logger } from "../lib/logger";

/**
 * Default VpnProvider. This project does not ship a real VPN daemon
 * integration — CONFIG GENERATION (services/configService.ts, always
 * real, always built from actual stored server/user data) is deliberately
 * kept separate from VPN SERVER PROVISIONING (actually making a daemon
 * accept that config), which requires talking to whatever software you
 * run on your VPN servers (Xray, sing-box, a custom WireGuard manager,
 * etc).
 *
 * NullVpnProvider is honest about this: it never claims success. Every
 * call returns PENDING with an explanation, and the caller
 * (vpnProvisioningService) records that on VpnUser.provisioningStatus /
 * provisioningMessage so the UI can show it truthfully instead of
 * implying a working server exists.
 *
 * To go live: implement VpnProvider against your real orchestration
 * layer (e.g. an SSH/API call to the target server, or a message to a
 * queue your daemon consumes) and point providers/index.ts at it.
 */
export class NullVpnProvider implements VpnProvider {
  readonly name = "null";

  async provisionUser(params: { userId: string; serverId: string; protocol: string; port: number; uuid: string }): Promise<VpnProvisionResult> {
    logger.info("NullVpnProvider.provisionUser called — no real daemon configured", {
      userId: params.userId,
      serverId: params.serverId,
    });
    return {
      status: "PENDING",
      message:
        "No VpnProvider is configured (VPN_PROVIDER env var unset or 'null'). A connection configuration was generated, " +
        "but nothing has actually configured a VPN server to accept it. Implement providers/vpnProvider.ts against your " +
        "real daemon and set VPN_PROVIDER to enable real provisioning.",
    };
  }

  async deprovisionUser(params: { userId: string; serverId: string }): Promise<VpnProvisionResult> {
    logger.info("NullVpnProvider.deprovisionUser called — no real daemon configured", params);
    return {
      status: "PENDING",
      message: "No VpnProvider is configured; nothing to deprovision on a real server.",
    };
  }
}
