import { prisma } from "../lib/prisma";
import { TrafficProvider, TrafficReportInput, RequestReportInput } from "./types";

/**
 * The only TrafficProvider implementation shipped today. It is the real
 * database-backed sink for usage reports — "database" here refers to where
 * results land, not to the authenticity of the data: every call is
 * expected to originate from an authorized, authenticated reporter (the
 * ingestion API in routes/ingest.ts), never from randomly generated
 * numbers. Idempotency keys prevent a retried report from double-counting.
 */
export class DatabaseTrafficProvider implements TrafficProvider {
  async recordTraffic(input: TrafficReportInput): Promise<{ created: boolean; id: string }> {
    if (input.idempotencyKey) {
      const existing = await prisma.trafficUsage.findUnique({ where: { idempotencyKey: input.idempotencyKey } });
      if (existing) return { created: false, id: existing.id };
    }

    const row = await prisma.trafficUsage.create({
      data: {
        userId: input.userId,
        uploadBytes: input.uploadBytes,
        downloadBytes: input.downloadBytes,
        isEstimated: input.isEstimated,
        sourceApiKeyId: input.sourceApiKeyId,
        idempotencyKey: input.idempotencyKey,
        periodStart: input.periodStart,
        periodEnd: input.periodEnd,
      },
    });

    // Traffic-limit enforcement: suspend if the user has exceeded their cap.
    const user = await prisma.vpnUser.findUnique({ where: { id: input.userId } });
    if (user?.trafficLimitBytes) {
      const totalAgg = await prisma.trafficUsage.aggregate({
        where: { userId: input.userId },
        _sum: { uploadBytes: true, downloadBytes: true },
      });
      const total = (totalAgg._sum.uploadBytes ?? 0n) + (totalAgg._sum.downloadBytes ?? 0n);
      if (total >= user.trafficLimitBytes && user.status === "ACTIVE") {
        await prisma.vpnUser.update({ where: { id: user.id }, data: { status: "SUSPENDED" } });
        const { createNotification } = await import("../services/notificationService");
        await createNotification({
          level: "WARNING",
          title: "Traffic limit reached",
          message: `${user.username} was automatically suspended after exceeding their traffic limit.`,
        });
      }
    }

    return { created: true, id: row.id };
  }

  async recordRequests(input: RequestReportInput): Promise<{ created: boolean; id: string }> {
    if (input.idempotencyKey) {
      const existing = await prisma.requestUsage.findUnique({ where: { idempotencyKey: input.idempotencyKey } });
      if (existing) return { created: false, id: existing.id };
    }

    const row = await prisma.requestUsage.create({
      data: {
        userId: input.userId,
        count: input.count,
        idempotencyKey: input.idempotencyKey,
        periodStart: input.periodStart,
        periodEnd: input.periodEnd,
      },
    });

    const user = await prisma.vpnUser.findUnique({ where: { id: input.userId } });
    if (user?.requestLimit) {
      const totalAgg = await prisma.requestUsage.aggregate({ where: { userId: input.userId }, _sum: { count: true } });
      const total = totalAgg._sum.count ?? 0;
      if (total >= user.requestLimit && user.status === "ACTIVE") {
        await prisma.vpnUser.update({ where: { id: user.id }, data: { status: "SUSPENDED" } });
        const { createNotification } = await import("../services/notificationService");
        await createNotification({
          level: "WARNING",
          title: "Request limit reached",
          message: `${user.username} was automatically suspended after exceeding their request limit.`,
        });
      }
    }

    return { created: true, id: row.id };
  }
}
