import { CloudflareProvider } from "./types";
import * as cf from "../services/cloudflareService";

/**
 * Adapts the existing, fully real cloudflareService (services/cloudflareService.ts)
 * to the CloudflareProvider interface. All calls delegate to the official
 * Cloudflare API — nothing here is mocked.
 */
export class CloudflareApiProvider implements CloudflareProvider {
  async verifyToken(apiToken: string) {
    return cf.verifyToken(apiToken);
  }
  async listZones(accountDbId: string) {
    return cf.listZones(accountDbId);
  }
  async syncAccount(accountDbId: string) {
    // Delegates to the batch sync; per-account sync reuses the same code path.
    await cf.syncAllCloudflareAccounts();
  }
}
