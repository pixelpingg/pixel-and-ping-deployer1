import { prisma } from "../lib/prisma";
import { PresenceProvider, HeartbeatInput } from "./types";
import { logger } from "../lib/logger";

/**
 * Real presence tracking. "Online" is defined purely as: a ConnectionSession
 * exists with endedAt = null and lastHeartbeatAt within the configured
 * timeout. Nothing here is randomly generated — the only writers are
 * POST /api/ingest/heartbeat (an authenticated external caller) and the
 * scheduled cleanupStaleSessions() job.
 */
export class DatabasePresenceProvider implements PresenceProvider {
  async heartbeat(input: HeartbeatInput): Promise<{ connectionSessionId: string }> {
    const now = new Date();

    if (input.connectionSessionId) {
      const existing = await prisma.connectionSession.findUnique({ where: { id: input.connectionSessionId } });
      if (existing && !existing.endedAt) {
        await prisma.connectionSession.update({
          where: { id: existing.id },
          data: { lastHeartbeatAt: now, endpointId: input.endpointId ?? existing.endpointId },
        });
        await this.markUserOnline(input.userId, now, input.endpointId);
        return { connectionSessionId: existing.id };
      }
    }

    const session = await prisma.connectionSession.create({
      data: {
        userId: input.userId,
        serverId: input.serverId,
        endpointId: input.endpointId,
        clientIp: input.clientIp,
        startedAt: now,
        lastHeartbeatAt: now,
      },
    });

    await this.markUserOnline(input.userId, now, input.endpointId);
    return { connectionSessionId: session.id };
  }

  private async markUserOnline(userId: string, at: Date, endpointId?: string) {
    await prisma.vpnUser.update({
      where: { id: userId },
      data: { isOnline: true, lastSeenAt: at, ...(endpointId ? { lastEndpointId: endpointId } : {}) },
    });
  }

  async endSession(connectionSessionId: string, reason: string): Promise<void> {
    const session = await prisma.connectionSession.update({
      where: { id: connectionSessionId },
      data: { endedAt: new Date(), endReason: reason },
    });

    const stillOpen = await prisma.connectionSession.findFirst({
      where: { userId: session.userId, endedAt: null },
    });
    if (!stillOpen) {
      await prisma.vpnUser.update({ where: { id: session.userId }, data: { isOnline: false } });
    }
  }

  async cleanupStaleSessions(timeoutSeconds: number): Promise<{ markedOffline: number }> {
    const cutoff = new Date(Date.now() - timeoutSeconds * 1000);

    const staleSessions = await prisma.connectionSession.findMany({
      where: { endedAt: null, lastHeartbeatAt: { lt: cutoff } },
    });

    if (staleSessions.length === 0) return { markedOffline: 0 };

    await prisma.$transaction(
      staleSessions.map((s) =>
        prisma.connectionSession.update({
          where: { id: s.id },
          data: { endedAt: new Date(), endReason: "heartbeat_timeout" },
        })
      )
    );

    const affectedUserIds = [...new Set(staleSessions.map((s) => s.userId))];
    let markedOffline = 0;
    for (const userId of affectedUserIds) {
      const stillOpen = await prisma.connectionSession.findFirst({ where: { userId, endedAt: null } });
      if (!stillOpen) {
        await prisma.vpnUser.update({ where: { id: userId }, data: { isOnline: false } });
        markedOffline++;
      }
    }

    logger.debug("Presence cleanup", { staleSessions: staleSessions.length, markedOffline });
    return { markedOffline };
  }

  async getOnlineCount(): Promise<number> {
    return prisma.vpnUser.count({ where: { isOnline: true } });
  }
}
