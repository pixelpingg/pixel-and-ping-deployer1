import { TrafficProvider, PresenceProvider, VpnProvider, CloudflareProvider } from "./types";
import { DatabaseTrafficProvider } from "./databaseTrafficProvider";
import { DatabasePresenceProvider } from "./databasePresenceProvider";
import { NullVpnProvider } from "./nullVpnProvider";
import { CloudflareApiProvider } from "./cloudflareProvider";

/**
 * Provider factory / composition root. Swapping a provider for a real
 * integration (e.g. a real VpnProvider talking to your daemon) means
 * changing this file only — routes, services, and the entire frontend
 * are written against the interfaces in providers/types.ts and never
 * import a concrete class directly.
 *
 * Selection is env-driven so ops can point at a different implementation
 * per environment without a code change once more providers exist.
 */
const vpnProviderName = process.env.VPN_PROVIDER ?? "null";

function selectVpnProvider(): VpnProvider {
  switch (vpnProviderName) {
    // Add real providers here as they're implemented, e.g.:
    // case "xray-ssh": return new XraySshVpnProvider();
    case "null":
    default:
      return new NullVpnProvider();
  }
}

export const trafficProvider: TrafficProvider = new DatabaseTrafficProvider();
export const presenceProvider: PresenceProvider = new DatabasePresenceProvider();
export const vpnProvider: VpnProvider = selectVpnProvider();
export const cloudflareProvider: CloudflareProvider = new CloudflareApiProvider();

export * from "./types";
