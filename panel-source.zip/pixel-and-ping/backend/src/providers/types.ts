/**
 * Provider interfaces — Pixel & Ping talks to these abstractions, never
 * directly to a specific vendor/daemon implementation. Swapping the
 * concrete provider (e.g. a real VPN daemon adapter instead of
 * NullVpnProvider) requires no frontend or route changes: only the
 * factory in providers/index.ts needs to point at a different class.
 */

// ---------------------------------------------------------------------
// TrafficProvider — records and reads bandwidth/request usage. The
// "database" implementation is the source of truth either way; what
// varies is *who calls it*: the ingestion API (routes/ingest.ts) on
// behalf of an external VPN daemon, or an internal job.
// ---------------------------------------------------------------------
export interface TrafficReportInput {
  userId: string;
  uploadBytes: bigint;
  downloadBytes: bigint;
  periodStart: Date;
  periodEnd: Date;
  isEstimated: boolean;
  sourceApiKeyId?: string;
  idempotencyKey?: string;
}

export interface RequestReportInput {
  userId: string;
  count: number;
  periodStart: Date;
  periodEnd: Date;
  idempotencyKey?: string;
}

export interface TrafficProvider {
  recordTraffic(input: TrafficReportInput): Promise<{ created: boolean; id: string }>;
  recordRequests(input: RequestReportInput): Promise<{ created: boolean; id: string }>;
}

// ---------------------------------------------------------------------
// PresenceProvider — online/offline state, derived only from real
// heartbeats/connection sessions reported by an authorized client.
// ---------------------------------------------------------------------
export interface HeartbeatInput {
  userId: string;
  serverId?: string;
  endpointId?: string;
  clientIp?: string;
  connectionSessionId?: string; // if omitted, a new session is opened
}

export interface PresenceProvider {
  heartbeat(input: HeartbeatInput): Promise<{ connectionSessionId: string }>;
  endSession(connectionSessionId: string, reason: string): Promise<void>;
  cleanupStaleSessions(timeoutSeconds: number): Promise<{ markedOffline: number }>;
  getOnlineCount(): Promise<number>;
}

// ---------------------------------------------------------------------
// VpnProvider — actual VPN SERVER PROVISIONING, distinct from config
// *generation*. generateConfiguration() (services/configService.ts)
// always produces a real, well-formed config string from stored data,
// but that alone does not make a server accept connections. Only a
// concrete VpnProvider (talking to your real daemon/orchestrator) can
// make that true — this project ships with NullVpnProvider, which is
// explicit about doing nothing.
// ---------------------------------------------------------------------
export interface VpnProvisionResult {
  status: "PROVISIONED" | "PENDING" | "FAILED";
  message: string;
}

export interface VpnProvider {
  readonly name: string;
  provisionUser(params: { userId: string; serverId: string; protocol: string; port: number; uuid: string }): Promise<VpnProvisionResult>;
  deprovisionUser(params: { userId: string; serverId: string }): Promise<VpnProvisionResult>;
}

// ---------------------------------------------------------------------
// CloudflareProvider — thin interface over services/cloudflareService.ts
// so alternate CDN/edge providers could be substituted without touching
// routes/cloudflare.ts's shape (routes still import the concrete service
// directly today; this interface documents the seam for that future
// swap rather than being wired in yet).
// ---------------------------------------------------------------------
export interface CloudflareProvider {
  verifyToken(apiToken: string): Promise<{ status: string }>;
  listZones(accountDbId: string): Promise<{ id: string; name: string; status: string }[]>;
  syncAccount(accountDbId: string): Promise<void>;
}
