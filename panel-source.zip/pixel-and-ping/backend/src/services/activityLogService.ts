import { prisma } from "../lib/prisma";

export async function logActivity(input: {
  adminId?: string;
  action: string;
  targetType?: string;
  targetId?: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string;
}) {
  // Never pass secrets (tokens, passwords) into metadata — this table is
  // readable from the Activity Logs page.
  return prisma.activityLog.create({
    data: {
      adminId: input.adminId,
      action: input.action,
      targetType: input.targetType,
      targetId: input.targetId,
      metadata: input.metadata as any,
      ipAddress: input.ipAddress,
    },
  });
}
