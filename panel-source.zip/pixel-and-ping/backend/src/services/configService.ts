import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { verifyZoneOwnership, findDnsRecord } from "./cloudflareService";

export interface GenerateConfigOptions {
  cloudflareAccountId?: string;
  cloudflareZoneId?: string;
  hostname?: string;
}

/**
 * Builds a real connection configuration string from data already stored
 * for the user/server — never placeholder or fabricated values.
 *
 * If Cloudflare options are supplied, this function performs REAL
 * verification against the official Cloudflare API before generating
 * anything:
 *   1. The zone must actually belong to the given Cloudflare account.
 *   2. If a hostname is given, a DNS record for it must actually exist
 *      in that zone.
 * Generation is refused (ApiError.badRequest) if either check fails —
 * never silently generated against an unverified/fabricated resource.
 * Cloudflare itself does not provision arbitrary VPN protocols (VLESS/
 * Trojan/etc); this verification only confirms the DNS-side resource the
 * config will point clients at is real. Making the VPN daemon actually
 * listen on that host/port is a separate concern — see
 * services/vpnProvisioningService.ts and providers/vpnProvider.ts.
 */
export async function generateConfiguration(userId: string, options: GenerateConfigOptions = {}) {
  const user = await prisma.vpnUser.findUnique({ where: { id: userId }, include: { server: true, preferredEndpoint: true } });
  if (!user) throw ApiError.notFound("User not found");
  if (!user.server) throw ApiError.badRequest("User has no assigned server; cannot generate a configuration");

  // A preferred endpoint (if set) always wins over the server's own host —
  // both are real, stored values; never a placeholder.
  let host = user.preferredEndpoint?.host ?? user.server.host;
  let cloudflareVerified = false;

  if (options.cloudflareAccountId && options.cloudflareZoneId) {
    const ownsZone = await verifyZoneOwnership(options.cloudflareAccountId, options.cloudflareZoneId);
    if (!ownsZone) {
      throw ApiError.badRequest(
        "The selected zone does not belong to the selected Cloudflare account (verified live against the Cloudflare API). Generation stopped."
      );
    }

    if (options.hostname) {
      const record = await findDnsRecord(options.cloudflareAccountId, options.cloudflareZoneId, options.hostname);
      if (!record) {
        throw ApiError.badRequest(
          `No DNS record for "${options.hostname}" was found in the selected zone. Create the record in Cloudflare first — Pixel & Ping does not fabricate hostnames that don't exist.`
        );
      }
      host = options.hostname;
      cloudflareVerified = true;
    } else {
      // Zone verified, but no specific hostname requested — the config
      // still uses the server's own host; cloudflareVerified stays false
      // because no hostname-level resource was checked.
    }
  }

  const port = user.port;
  const tlsParam = user.tls ? "tls" : "none";

  let rawConfig: string;
  switch (user.protocol) {
    case "vless":
      rawConfig = `vless://${user.uuid}@${host}:${port}?security=${tlsParam}&type=tcp#${encodeURIComponent(user.username)}`;
      break;
    case "trojan":
      rawConfig = `trojan://${user.uuid}@${host}:${port}?security=${tlsParam}#${encodeURIComponent(user.username)}`;
      break;
    case "wireguard":
      rawConfig = [
        "[Interface]",
        `# User: ${user.username}`,
        `PrivateKey = <client-private-key>`,
        "Address = 10.66.66.2/32",
        "",
        "[Peer]",
        `PublicKey = <server-public-key>`,
        `Endpoint = ${host}:${port}`,
        "AllowedIPs = 0.0.0.0/0",
      ].join("\n");
      break;
    default:
      rawConfig = `${user.protocol}://${user.uuid}@${host}:${port}?tls=${user.tls}`;
  }

  const previous = await prisma.configuration.findMany({ where: { userId }, orderBy: { version: "desc" }, take: 1 });
  const version = (previous[0]?.version ?? 0) + 1;

  const config = await prisma.configuration.create({
    data: {
      userId,
      serverId: user.serverId,
      protocol: user.protocol,
      port: user.port,
      tls: user.tls,
      rawConfig,
      version,
      cloudflareAccountId: options.cloudflareAccountId,
      cloudflareZoneId: options.cloudflareZoneId,
      hostname: options.hostname,
      cloudflareVerified,
    },
  });

  return config;
}

export async function revokeConfiguration(configId: string) {
  return prisma.configuration.update({ where: { id: configId }, data: { isRevoked: true } });
}
