import { prisma } from "../lib/prisma";
import { createNotification } from "./notificationService";
import { logger } from "../lib/logger";

/**
 * Marks users whose expiresAt has passed as EXPIRED. Runs on a schedule
 * so expiration is enforced even if nobody opens the panel. Idempotent —
 * only transitions ACTIVE users, so it's safe to run frequently.
 */
export async function sweepExpiredUsers() {
  const now = new Date();
  const expired = await prisma.vpnUser.findMany({
    where: { status: "ACTIVE", expiresAt: { lt: now } },
  });

  if (expired.length === 0) return { expired: 0 };

  await prisma.$transaction(
    expired.map((u) => prisma.vpnUser.update({ where: { id: u.id }, data: { status: "EXPIRED" } }))
  );

  for (const u of expired) {
    await createNotification({
      level: "WARNING",
      title: "User expired",
      message: `${u.username}'s access expired and was automatically disabled.`,
    });
  }

  logger.info("Expiry sweep complete", { count: expired.length });
  return { expired: expired.length };
}
