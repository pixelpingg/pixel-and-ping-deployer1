import { prisma } from "../lib/prisma";
import { logger } from "../lib/logger";
import { createNotification } from "./notificationService";

/**
 * Evaluates a server's endpoints against the configured failure threshold
 * and, if enabled, fails over from an unhealthy primary endpoint to the
 * best available healthy alternative. All thresholds are operator
 * configurable via FailoverSettings.
 */
export async function evaluateFailover(serverId: string) {
  const settings = await prisma.failoverSettings.findFirst();
  if (!settings || !settings.enabled) return null;

  const endpoints = await prisma.endpoint.findMany({ where: { serverId } });
  const primary = endpoints.find((e) => e.isPrimary);
  if (!primary) return null;

  const recentChecks = await prisma.healthCheck.findMany({
    where: { endpointId: primary.id },
    orderBy: { checkedAt: "desc" },
    take: settings.failureThreshold,
  });

  const consecutiveFailures =
    recentChecks.length === settings.failureThreshold && recentChecks.every((c) => !c.success);

  if (!consecutiveFailures) return null;

  // Only ever select from endpoints CURRENTLY reporting acceptable health —
  // never a fixed/static list, never an endpoint the last real health
  // check marked unhealthy.
  const candidates = endpoints
    .filter((e) => e.id !== primary.id && e.health !== "OFFLINE" && e.health !== "POOR" && e.health !== "UNKNOWN")
    .sort((a, b) => b.score - a.score);

  const next = candidates[0];
  if (!next) {
    await createNotification({
      level: "CRITICAL",
      title: "Failover unavailable",
      message: `Endpoint ${primary.label} is unhealthy and no healthy alternative was found.`,
    });
    return null;
  }

  // Step-verify the candidate with a fresh health probe before switching —
  // never fail over onto an endpoint based on stale/cached health alone.
  const { checkEndpointHealth } = await import("./healthCheckService");
  const verified = await checkEndpointHealth(next.id);
  if (verified.health === "OFFLINE" || verified.health === "POOR") {
    logger.warn("Failover candidate failed re-verification, skipping switch", { endpointId: next.id });
    return null;
  }

  await prisma.$transaction([
    prisma.endpoint.update({ where: { id: primary.id }, data: { isPrimary: false } }),
    prisma.endpoint.update({ where: { id: next.id }, data: { isPrimary: true } }),
    prisma.failoverEvent.create({
      data: {
        fromEndpointId: primary.id,
        toEndpointId: next.id,
        reason: `Primary endpoint failed ${settings.failureThreshold}+ consecutive health checks`,
        automatic: true,
      },
    }),
  ]);

  await createNotification({
    level: "WARNING",
    title: "Automatic failover triggered",
    message: `Traffic moved from ${primary.label} to ${next.label}.`,
  });

  logger.info("Failover executed", { from: primary.id, to: next.id, serverId });
  return { from: primary, to: next };
}

/**
 * Recovery policy: if the endpoint that was demoted in the most recent
 * failover event for this server has since logged `recoveryThreshold`
 * consecutive successful health checks and now scores at least as well as
 * the current primary, fail back to it. This is deliberately conservative
 * — recovery only triggers on sustained, freshly-measured health, never
 * on a single good check.
 */
export async function evaluateRecovery(serverId: string) {
  const settings = await prisma.failoverSettings.findFirst();
  if (!settings || !settings.enabled) return null;

  const lastEvent = await prisma.failoverEvent.findFirst({
    where: { toEndpoint: { serverId } },
    orderBy: { triggeredAt: "desc" },
    include: { fromEndpoint: true, toEndpoint: true },
  });
  if (!lastEvent || !lastEvent.fromEndpointId || !lastEvent.fromEndpoint) return null;

  const demoted = lastEvent.fromEndpoint;
  const currentPrimary = lastEvent.toEndpoint;
  if (!currentPrimary || demoted.isPrimary) return null; // already back, or nothing to recover

  const recentChecks = await prisma.healthCheck.findMany({
    where: { endpointId: demoted.id },
    orderBy: { checkedAt: "desc" },
    take: settings.recoveryThreshold,
  });
  const consecutiveSuccesses =
    recentChecks.length === settings.recoveryThreshold && recentChecks.every((c) => c.success);
  if (!consecutiveSuccesses) return null;

  const freshDemoted = await prisma.endpoint.findUniqueOrThrow({ where: { id: demoted.id } });
  const freshPrimary = await prisma.endpoint.findUniqueOrThrow({ where: { id: currentPrimary.id } });
  if (freshDemoted.score < freshPrimary.score) return null;

  await prisma.$transaction([
    prisma.endpoint.update({ where: { id: freshPrimary.id }, data: { isPrimary: false } }),
    prisma.endpoint.update({ where: { id: freshDemoted.id }, data: { isPrimary: true } }),
    prisma.failoverEvent.create({
      data: {
        fromEndpointId: freshPrimary.id,
        toEndpointId: freshDemoted.id,
        reason: `Recovered endpoint passed ${settings.recoveryThreshold} consecutive health checks — failed back`,
        automatic: true,
      },
    }),
  ]);

  await createNotification({
    level: "INFO",
    title: "Endpoint recovered",
    message: `${freshDemoted.label} recovered and traffic failed back to it.`,
  });

  logger.info("Failback executed", { from: freshPrimary.id, to: freshDemoted.id, serverId });
  return { from: freshPrimary, to: freshDemoted };
}

export async function evaluateFailoverForAllServers() {
  const servers = await prisma.server.findMany({ where: { isEnabled: true } });
  const results = [];
  for (const server of servers) {
    const failoverResult = await evaluateFailover(server.id);
    if (failoverResult) {
      results.push({ serverId: server.id, ...failoverResult });
      continue;
    }
    const recoveryResult = await evaluateRecovery(server.id);
    if (recoveryResult) results.push({ serverId: server.id, ...recoveryResult });
  }
  return results;
}
