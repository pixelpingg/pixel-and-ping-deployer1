import { prisma } from "../lib/prisma";
import { vpnProvider } from "../providers";
import { logger } from "../lib/logger";
import { createNotification } from "./notificationService";

/**
 * Bridges CONFIG GENERATION (services/configService.ts — always produces a
 * real, well-formed config string from stored data) and VPN SERVER
 * PROVISIONING (actually making a server accept it — requires a real
 * VpnProvider). Call this after generateConfiguration() if you want the
 * panel to also attempt provisioning; skip it if you only want to hand
 * operators a config to apply manually.
 */
export async function attemptProvisioning(userId: string) {
  const user = await prisma.vpnUser.findUnique({ where: { id: userId } });
  if (!user || !user.serverId) {
    logger.warn("attemptProvisioning called without a server assigned", { userId });
    return;
  }

  await prisma.vpnUser.update({ where: { id: userId }, data: { provisioningStatus: "PENDING", provisioningMessage: null } });

  const result = await vpnProvider.provisionUser({
    userId: user.id,
    serverId: user.serverId,
    protocol: user.protocol,
    port: user.port,
    uuid: user.uuid,
  });

  await prisma.vpnUser.update({
    where: { id: userId },
    data: { provisioningStatus: result.status, provisioningMessage: result.message },
  });

  if (result.status === "FAILED") {
    await createNotification({
      level: "ERROR",
      title: "VPN provisioning failed",
      message: `${user.username}: ${result.message}`,
    });
  }

  return result;
}

export async function attemptDeprovisioning(userId: string) {
  const user = await prisma.vpnUser.findUnique({ where: { id: userId } });
  if (!user || !user.serverId) return;

  const result = await vpnProvider.deprovisionUser({ userId: user.id, serverId: user.serverId });

  await prisma.vpnUser.update({
    where: { id: userId },
    data: { provisioningStatus: "DEPROVISIONED", provisioningMessage: result.message },
  });

  return result;
}
