import { prisma } from "../lib/prisma";
import { NotificationLevel } from "@prisma/client";

export async function createNotification(input: {
  level: NotificationLevel | "INFO" | "WARNING" | "ERROR" | "CRITICAL";
  title: string;
  message: string;
  metadata?: Record<string, unknown>;
}) {
  return prisma.notification.create({
    data: {
      level: input.level as NotificationLevel,
      title: input.title,
      message: input.message,
      metadata: input.metadata as any,
    },
  });
}
