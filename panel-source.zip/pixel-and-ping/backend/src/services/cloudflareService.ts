import { prisma } from "../lib/prisma";
import { decryptSecret, encryptSecret, redactToken } from "../lib/crypto";
import { logger } from "../lib/logger";
import { ApiError } from "../lib/errors";

const CF_API_BASE = "https://api.cloudflare.com/client/v4";

interface CfListResponse<T> {
  success: boolean;
  errors: { code: number; message: string }[];
  result: T;
  result_info?: { total_count?: number };
}

/**
 * All Cloudflare API access happens here, server-side only. Tokens are
 * decrypted in-memory for the duration of a single request and never
 * returned to the frontend, logged, or persisted anywhere but the
 * encrypted DB column.
 */
async function cfFetch<T>(token: string, path: string, init?: RequestInit, attempt = 1): Promise<T> {
  const maxAttempts = 3;
  const res = await fetch(`${CF_API_BASE}${path}`, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
      ...(init?.headers ?? {}),
    },
  });

  if (res.status === 401 || res.status === 403) {
    throw ApiError.upstream("Cloudflare rejected the API token (unauthorized). Check the token's permissions.");
  }

  // Retry with exponential backoff on rate limiting or transient server
  // errors — never on 4xx client errors, which won't succeed on retry.
  if ((res.status === 429 || res.status >= 500) && attempt < maxAttempts) {
    const retryAfterHeader = res.headers.get("retry-after");
    const delayMs = retryAfterHeader ? Number(retryAfterHeader) * 1000 : 300 * 2 ** attempt;
    logger.warn("Cloudflare API request throttled/failed, retrying", { path, status: res.status, attempt, delayMs });
    await new Promise((resolve) => setTimeout(resolve, delayMs));
    return cfFetch<T>(token, path, init, attempt + 1);
  }

  if (res.status === 429) {
    throw ApiError.upstream("Cloudflare API rate limit reached. Try again shortly.");
  }
  if (res.status >= 500) {
    throw ApiError.upstream("Cloudflare API is currently unavailable.");
  }

  const body = (await res.json()) as CfListResponse<T>;
  if (!body.success) {
    const msg = body.errors?.[0]?.message ?? "Unknown Cloudflare API error";
    throw ApiError.upstream(`Cloudflare API error: ${msg}`);
  }
  return body.result;
}

export function getTokenFromAccount(account: {
  encryptedToken: string;
  tokenIv: string;
  tokenAuthTag: string;
}): string {
  return decryptSecret({
    ciphertext: account.encryptedToken,
    iv: account.tokenIv,
    authTag: account.tokenAuthTag,
  });
}

export async function addCloudflareAccount(input: { name: string; accountId: string; apiToken: string }) {
  const { ciphertext, iv, authTag } = encryptSecret(input.apiToken);

  // Verify the token works before saving it.
  await verifyToken(input.apiToken);

  const account = await prisma.cloudflareAccount.create({
    data: {
      name: input.name,
      accountId: input.accountId,
      encryptedToken: ciphertext,
      tokenIv: iv,
      tokenAuthTag: authTag,
      status: "HEALTHY",
      lastSyncAt: new Date(),
    },
  });

  logger.info("Cloudflare account added", { accountId: account.accountId, token: redactToken(input.apiToken) });
  return account;
}

export async function verifyToken(apiToken: string): Promise<{ status: string }> {
  // /user/tokens/verify works for any scoped API token.
  const result = await cfFetch<{ status: string }>(apiToken, "/user/tokens/verify");
  return result;
}

export async function testConnection(accountDbId: string) {
  const account = await prisma.cloudflareAccount.findUniqueOrThrow({ where: { id: accountDbId } });
  const token = getTokenFromAccount(account);
  try {
    const result = await verifyToken(token);
    await prisma.cloudflareAccount.update({
      where: { id: accountDbId },
      data: { status: "HEALTHY", lastSyncAt: new Date(), lastSyncError: null },
    });
    return { ok: true, status: result.status };
  } catch (err) {
    const message = err instanceof ApiError ? err.message : "Connection failed";
    await prisma.cloudflareAccount.update({
      where: { id: accountDbId },
      data: { status: "UNHEALTHY", lastSyncError: message },
    });
    throw err;
  }
}

export interface CfZoneSummary {
  id: string;
  name: string;
  status: string;
}

export async function listZones(accountDbId: string): Promise<CfZoneSummary[]> {
  const account = await prisma.cloudflareAccount.findUniqueOrThrow({ where: { id: accountDbId } });
  const token = getTokenFromAccount(account);
  const zones = await cfFetch<CfZoneSummary[]>(
    token,
    `/zones?account.id=${encodeURIComponent(account.accountId)}&per_page=50`
  );
  return zones.map((z) => ({ id: z.id, name: z.name, status: z.status }));
}

export interface CfWorkerSummary {
  id: string;
  createdOn?: string;
  modifiedOn?: string;
}

// Workers usage requires the Workers Scripts API + GraphQL Analytics API,
// which are only available on plans/tokens with the relevant scope. If the
// token lacks that scope, this returns null and the caller must surface
// "Unavailable from Cloudflare API" rather than fabricate data.
export async function listWorkers(accountDbId: string): Promise<CfWorkerSummary[] | null> {
  const account = await prisma.cloudflareAccount.findUniqueOrThrow({ where: { id: accountDbId } });
  const token = getTokenFromAccount(account);
  try {
    const result = await cfFetch<any[]>(token, `/accounts/${account.accountId}/workers/scripts`);
    return result.map((w) => ({ id: w.id, createdOn: w.created_on, modifiedOn: w.modified_on }));
  } catch (err) {
    logger.warn("Workers scripts unavailable for account", { accountId: account.accountId });
    return null;
  }
}

// Request/bandwidth analytics via the GraphQL Analytics API (zone-scoped).
// Requires an `Analytics:Read` scoped token. If unavailable, the caller
// must show "Unavailable from Cloudflare API" — never a fabricated number.
export async function fetchZoneAnalytics(
  accountDbId: string,
  zoneId: string,
  sinceISO: string,
  untilISO: string
): Promise<{ requests: number; bandwidthBytes: number } | null> {
  const account = await prisma.cloudflareAccount.findUniqueOrThrow({ where: { id: accountDbId } });
  const token = getTokenFromAccount(account);

  const query = `
    query ZoneAnalytics($zoneTag: String!, $since: Time!, $until: Time!) {
      viewer {
        zones(filter: { zoneTag: $zoneTag }) {
          httpRequests1dGroups(limit: 31, filter: { date_geq: $since, date_leq: $until }) {
            sum { requests, bytes }
          }
        }
      }
    }`;

  const res = await fetch("https://api.cloudflare.com/client/v4/graphql", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      query,
      variables: { zoneTag: zoneId, since: sinceISO, until: untilISO },
    }),
  });

  if (!res.ok) return null;
  const json = await res.json();
  const groups = json?.data?.viewer?.zones?.[0]?.httpRequests1dGroups;
  if (!groups || groups.length === 0) return null;

  const totals = groups.reduce(
    (acc: { requests: number; bandwidthBytes: number }, g: any) => {
      acc.requests += g.sum?.requests ?? 0;
      acc.bandwidthBytes += g.sum?.bytes ?? 0;
      return acc;
    },
    { requests: 0, bandwidthBytes: 0 }
  );
  return totals;
}

/**
 * Periodic sync job: refreshes status + usage snapshot for every active
 * Cloudflare account. Intended to be called from a scheduler (see
 * src/services/scheduler.ts). Never invents data — if a metric can't be
 * retrieved, the snapshot is stored with dataAvailable=false.
 */
export async function syncAllCloudflareAccounts() {
  const accounts = await prisma.cloudflareAccount.findMany({ where: { isActive: true } });
  for (const account of accounts) {
    try {
      const token = getTokenFromAccount(account);
      await verifyToken(token);
      const zones = await listZones(account.id);

      if (zones.length === 0) {
        await prisma.cloudflareUsageSnapshot.create({
          data: { accountId: account.id, dataAvailable: false, source: "Cloudflare API (no zones on account)" },
        });
      }

      // One snapshot per zone — never a single blended number across zones
      // the account may not equally have visibility into.
      for (const zone of zones) {
        try {
          const today = new Date();
          const since = new Date(today.getTime() - 24 * 60 * 60 * 1000).toISOString().slice(0, 10);
          const until = today.toISOString().slice(0, 10);
          const analytics = await fetchZoneAnalytics(account.id, zone.id, since, until);

          await prisma.cloudflareUsageSnapshot.create({
            data: {
              accountId: account.id,
              zoneId: zone.id,
              zoneName: zone.name,
              requestsToday: analytics?.requests ?? null,
              bandwidthBytes: analytics ? BigInt(analytics.bandwidthBytes) : null,
              dataAvailable: !!analytics,
              source: analytics ? "Cloudflare GraphQL Analytics API" : "Unavailable from Cloudflare API",
            },
          });
        } catch (zoneErr) {
          logger.warn("Zone analytics sync failed", { accountId: account.accountId, zoneId: zone.id });
          await prisma.cloudflareUsageSnapshot.create({
            data: {
              accountId: account.id,
              zoneId: zone.id,
              zoneName: zone.name,
              dataAvailable: false,
              source: "Unavailable from Cloudflare API",
            },
          });
        }
      }

      await prisma.cloudflareAccount.update({
        where: { id: account.id },
        data: { status: "HEALTHY", lastSyncAt: new Date(), lastSyncError: null },
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Sync failed";
      logger.warn("Cloudflare sync failed for account", { accountId: account.accountId, message });
      await prisma.cloudflareAccount.update({
        where: { id: account.id },
        data: { status: "UNHEALTHY", lastSyncError: message },
      });
      await prisma.cloudflareUsageSnapshot.create({
        data: { accountId: account.id, dataAvailable: false, source: "Unavailable from Cloudflare API" },
      });
    }
  }
}

// ---------------------------------------------------------------------
// Resource verification for the Config Generator (see
// services/configService.ts). Never assume a hostname/DNS record exists —
// always confirm it against the real Cloudflare API before a
// Configuration is allowed to reference it.
// ---------------------------------------------------------------------
export interface CfDnsRecordSummary {
  id: string;
  type: string;
  name: string;
  content: string;
  proxied: boolean;
}

export async function findDnsRecord(
  accountDbId: string,
  zoneId: string,
  hostname: string
): Promise<CfDnsRecordSummary | null> {
  const account = await prisma.cloudflareAccount.findUniqueOrThrow({ where: { id: accountDbId } });
  const token = getTokenFromAccount(account);
  const records = await cfFetch<any[]>(
    token,
    `/zones/${zoneId}/dns_records?name=${encodeURIComponent(hostname)}`
  );
  if (!records || records.length === 0) return null;
  const r = records[0];
  return { id: r.id, type: r.type, name: r.name, content: r.content, proxied: !!r.proxied };
}

export async function verifyZoneOwnership(accountDbId: string, zoneId: string): Promise<boolean> {
  const zones = await listZones(accountDbId);
  return zones.some((z) => z.id === zoneId);
}
