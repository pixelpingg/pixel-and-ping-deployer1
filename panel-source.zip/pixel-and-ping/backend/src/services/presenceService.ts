import { presenceProvider } from "../providers";
import { env } from "../lib/env";

/**
 * Thin wrapper so the scheduler doesn't need to know about the provider
 * abstraction directly. Timeout is configurable via PRESENCE_TIMEOUT_SEC.
 */
export async function cleanupStalePresence() {
  return presenceProvider.cleanupStaleSessions(env.PRESENCE_TIMEOUT_SEC);
}
