import net from "net";
import tls from "tls";
import { prisma } from "../lib/prisma";
import { logger } from "../lib/logger";

export interface HealthResult {
  success: boolean;
  latencyMs: number | null;
  tlsOk: boolean | null;
  httpStatus: number | null;
  errorMessage: string | null;
}

/**
 * Performs a TCP connect (+ optional TLS handshake) health probe against a
 * single, explicitly-configured endpoint that the operator has added to
 * their own inventory (Server/Endpoint records). This module intentionally
 * does NOT support scanning arbitrary hosts, port ranges, or third-party
 * infrastructure — only the exact host:port pairs already stored for
 * servers/endpoints the operator manages.
 */
export async function probeEndpoint(host: string, port: number, useTls: boolean, timeoutMs = 5000): Promise<HealthResult> {
  const start = Date.now();
  return new Promise((resolve) => {
    const onError = (err: Error) => {
      resolve({ success: false, latencyMs: null, tlsOk: null, httpStatus: null, errorMessage: err.message });
    };

    const timer = setTimeout(() => {
      socket.destroy();
      resolve({ success: false, latencyMs: null, tlsOk: null, httpStatus: null, errorMessage: "Timed out" });
    }, timeoutMs);

    const socket = useTls
      ? tls.connect({ host, port, timeout: timeoutMs, rejectUnauthorized: false }, () => {
          clearTimeout(timer);
          const latencyMs = Date.now() - start;
          const tlsOk = (socket as tls.TLSSocket).authorized || true; // handshake succeeded
          socket.end();
          resolve({ success: true, latencyMs, tlsOk, httpStatus: null, errorMessage: null });
        })
      : net.connect({ host, port, timeout: timeoutMs }, () => {
          clearTimeout(timer);
          const latencyMs = Date.now() - start;
          socket.end();
          resolve({ success: true, latencyMs, tlsOk: null, httpStatus: null, errorMessage: null });
        });

    socket.on("error", (err) => {
      clearTimeout(timer);
      onError(err as Error);
    });
  });
}

// Computes a 0-100 IP Score from recent health-check history.
export function computeScore(params: {
  successRatio: number; // 0..1 over the recent window
  avgLatencyMs: number | null;
  packetLossPct: number | null;
}): number {
  const { successRatio, avgLatencyMs, packetLossPct } = params;
  // Every recent probe failed — this is a known fact, not missing data,
  // so the "neutral bonus for unknown" logic below must not apply. Without
  // this early return, the flat +15/+5 bonuses always pushed the score to
  // at least 20, making scoreToHealthLabel's score===0 "OFFLINE" branch
  // mathematically unreachable — a fully dead endpoint was permanently
  // mislabeled "POOR" instead of "OFFLINE".
  if (successRatio === 0) return 0;

  let score = successRatio * 60; // availability weighs most

  if (avgLatencyMs !== null) {
    const latencyScore = Math.max(0, 30 - avgLatencyMs / 20); // 0ms=30pts, 600ms+=0pts
    score += Math.min(30, latencyScore);
  } else {
    score += 15; // neutral if unknown
  }

  if (packetLossPct !== null) {
    score += Math.max(0, 10 - packetLossPct / 2);
  } else {
    score += 5;
  }

  return Math.max(0, Math.min(100, Math.round(score)));
}

export function scoreToHealthLabel(score: number): "EXCELLENT" | "GOOD" | "FAIR" | "POOR" | "OFFLINE" {
  if (score === 0) return "OFFLINE";
  if (score >= 85) return "EXCELLENT";
  if (score >= 65) return "GOOD";
  if (score >= 40) return "FAIR";
  return "POOR";
}

/**
 * Runs a health check for a single endpoint, stores the HealthCheck row,
 * recomputes the rolling score, and updates the Endpoint record.
 */
export async function checkEndpointHealth(endpointId: string) {
  const endpoint = await prisma.endpoint.findUniqueOrThrow({ where: { id: endpointId } });
  const result = await probeEndpoint(endpoint.host, endpoint.port, true);

  await prisma.healthCheck.create({
    data: {
      endpointId: endpoint.id,
      serverId: endpoint.serverId,
      latencyMs: result.latencyMs,
      tlsOk: result.tlsOk,
      httpStatus: result.httpStatus,
      success: result.success,
      errorMessage: result.errorMessage,
    },
  });

  const recent = await prisma.healthCheck.findMany({
    where: { endpointId: endpoint.id },
    orderBy: { checkedAt: "desc" },
    take: 20,
  });

  const successRatio = recent.filter((r) => r.success).length / recent.length;
  const latencies = recent.filter((r) => r.latencyMs !== null).map((r) => r.latencyMs as number);
  const avgLatencyMs = latencies.length ? latencies.reduce((a, b) => a + b, 0) / latencies.length : null;

  const score = computeScore({ successRatio, avgLatencyMs, packetLossPct: null });
  const health = scoreToHealthLabel(score);
  const previousHealth = endpoint.health;

  const updated = await prisma.endpoint.update({
    where: { id: endpoint.id },
    data: {
      latencyMs: result.latencyMs,
      tlsOk: result.tlsOk,
      httpStatus: result.httpStatus,
      score,
      health,
      lastCheckedAt: new Date(),
    },
  });

  // Surface real health transitions as notifications — never synthetic,
  // always keyed off the actual before/after health label.
  const wasUnhealthy = previousHealth === "OFFLINE" || previousHealth === "POOR";
  const isUnhealthyNow = health === "OFFLINE" || health === "POOR";
  if (!wasUnhealthy && isUnhealthyNow) {
    const { createNotification } = await import("./notificationService");
    await createNotification({
      level: "WARNING",
      title: "Endpoint unhealthy",
      message: `${endpoint.label} degraded to ${health}.`,
    });
  } else if (wasUnhealthy && !isUnhealthyNow) {
    const { createNotification } = await import("./notificationService");
    await createNotification({
      level: "INFO",
      title: "Endpoint recovered",
      message: `${endpoint.label} recovered to ${health}.`,
    });
  }

  logger.debug("Endpoint health checked", { endpointId, health, score });
  return updated;
}

export async function checkAllEndpoints() {
  const endpoints = await prisma.endpoint.findMany();
  const results = [];
  for (const ep of endpoints) {
    try {
      results.push(await checkEndpointHealth(ep.id));
    } catch (err) {
      logger.warn("Health check failed for endpoint", { endpointId: ep.id });
    }
  }
  return results;
}
