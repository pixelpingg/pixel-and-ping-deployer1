import { logger } from "../lib/logger";
import { syncAllCloudflareAccounts } from "./cloudflareService";
import { checkAllEndpoints } from "./healthCheckService";
import { evaluateFailoverForAllServers } from "./failoverService";
import { cleanupStalePresence } from "./presenceService";
import { sweepExpiredUsers } from "./expiryService";
import { prisma } from "../lib/prisma";

/**
 * Lightweight in-process scheduler. For production at scale, replace with
 * a real job queue (BullMQ/Agenda) — this is intentionally simple and
 * dependency-free so the panel works out of the box in Docker Compose.
 */
export function startScheduler() {
  const healthIntervalMs = 30_000;
  const cloudflareSyncIntervalMs = 5 * 60_000;
  const presenceCleanupIntervalMs = 30_000;

  setInterval(async () => {
    try {
      await checkAllEndpoints();
      const settings = await prisma.failoverSettings.findFirst();
      if (settings?.enabled) {
        await evaluateFailoverForAllServers();
      }
    } catch (err) {
      logger.warn("Scheduled health check cycle failed", { err: err instanceof Error ? err.message : err });
    }
  }, healthIntervalMs);

  setInterval(async () => {
    try {
      await syncAllCloudflareAccounts();
    } catch (err) {
      logger.warn("Scheduled Cloudflare sync failed", { err: err instanceof Error ? err.message : err });
    }
  }, cloudflareSyncIntervalMs);

  // Marks users offline whose ConnectionSession has gone stale (no
  // heartbeat within PRESENCE_TIMEOUT_SEC) — the only automatic writer
  // of isOnline=false besides an explicit /api/ingest/session/end call.
  setInterval(async () => {
    try {
      const result = await cleanupStalePresence();
      if (result.markedOffline > 0) {
        logger.debug("Presence cleanup marked users offline", result);
      }
    } catch (err) {
      logger.warn("Scheduled presence cleanup failed", { err: err instanceof Error ? err.message : err });
    }
  }, presenceCleanupIntervalMs);

  logger.info("Scheduler started", { healthIntervalMs, cloudflareSyncIntervalMs, presenceCleanupIntervalMs });

  const expirySweepIntervalMs = 5 * 60_000;
  setInterval(async () => {
    try {
      await sweepExpiredUsers();
    } catch (err) {
      logger.warn("Scheduled expiry sweep failed", { err: err instanceof Error ? err.message : err });
    }
  }, expirySweepIntervalMs);
}
