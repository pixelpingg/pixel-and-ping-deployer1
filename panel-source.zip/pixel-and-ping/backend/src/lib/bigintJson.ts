// Express's res.json() uses JSON.stringify, which throws
// "Do not know how to serialize a BigInt" for any Prisma BigInt field
// (TrafficUsage.uploadBytes, VpnUser.trafficLimitBytes,
// CloudflareUsageSnapshot.bandwidthBytes, etc) unless it's explicitly
// converted first. Rather than requiring every route to remember to call
// .toString() on every BigInt field it might return (error-prone — a
// missed one is a 500 in production), this defines a global toJSON so
// any BigInt anywhere in a response serializes safely as a string.
// Routes that already convert explicitly (e.g. routes/traffic.ts) are
// unaffected — this only applies where a raw BigInt would otherwise
// reach JSON.stringify.
declare global {
  interface BigInt {
    toJSON(): string;
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
(BigInt.prototype as any).toJSON = function () {
  return this.toString();
};

export {};
