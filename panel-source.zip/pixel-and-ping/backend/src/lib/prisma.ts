import { PrismaClient } from "@prisma/client";

// Single shared Prisma instance. In dev with hot-reload (tsx watch),
// reuse the client across reloads to avoid exhausting DB connections.
declare global {
  // eslint-disable-next-line no-var
  var __prisma: PrismaClient | undefined;
}

export const prisma =
  global.__prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  global.__prisma = prisma;
}
