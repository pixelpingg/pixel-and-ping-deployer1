import dotenv from "dotenv";
dotenv.config();

function required(name: string, fallback?: string): string {
  const v = process.env[name] ?? fallback;
  if (v === undefined) {
    // Do not throw at import time in dev-friendly scripts (e.g. prisma),
    // but warn loudly so misconfiguration is obvious.
    // eslint-disable-next-line no-console
    console.warn(`[env] Missing required environment variable: ${name}`);
    return "";
  }
  return v;
}

export const env = {
  NODE_ENV: process.env.NODE_ENV ?? "development",
  PORT: Number(process.env.PORT ?? 4000),
  FRONTEND_ORIGIN: process.env.FRONTEND_ORIGIN ?? "http://localhost:5173",
  DATABASE_URL: required("DATABASE_URL"),
  JWT_SECRET: required("JWT_SECRET"),
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN ?? "15m",
  REFRESH_TOKEN_EXPIRES_IN: process.env.REFRESH_TOKEN_EXPIRES_IN ?? "7d",
  SESSION_COOKIE_NAME: process.env.SESSION_COOKIE_NAME ?? "pp_session",
  COOKIE_SECURE: (process.env.COOKIE_SECURE ?? "false") === "true",
  ENCRYPTION_KEY: required("ENCRYPTION_KEY"),
  RATE_LIMIT_WINDOW_MS: Number(process.env.RATE_LIMIT_WINDOW_MS ?? 60000),
  RATE_LIMIT_MAX: Number(process.env.RATE_LIMIT_MAX ?? 100),
  PRESENCE_TIMEOUT_SEC: Number(process.env.PRESENCE_TIMEOUT_SEC ?? 90),
  VPN_PROVIDER: process.env.VPN_PROVIDER ?? "null",
};
