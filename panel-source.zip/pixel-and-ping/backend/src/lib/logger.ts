import winston from "winston";

// Structured logger. IMPORTANT: never pass secrets (tokens, passwords,
// session cookies) into log calls — see lib/crypto.ts#redactToken for
// values that must be redacted before logging.
export const logger = winston.createLogger({
  level: process.env.NODE_ENV === "development" ? "debug" : "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [new winston.transports.Console()],
});
