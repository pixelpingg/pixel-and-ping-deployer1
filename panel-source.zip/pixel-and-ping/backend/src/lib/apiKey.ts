import crypto from "crypto";
import bcrypt from "bcryptjs";

// Ingestion API keys look like `pp_live_<40 hex chars>`. Only the bcrypt
// hash is ever persisted; the prefix (pp_live_ + first 8 chars) is stored
// separately so the UI can show "pp_live_a1b2c3d4…" for identification
// without ever re-displaying the full key after creation.
export function generateApiKey(): { plaintext: string; prefix: string } {
  const raw = crypto.randomBytes(24).toString("hex");
  const plaintext = `pp_live_${raw}`;
  const prefix = plaintext.slice(0, 16);
  return { plaintext, prefix };
}

export async function hashApiKey(plaintext: string): Promise<string> {
  return bcrypt.hash(plaintext, 10);
}

export async function verifyApiKey(plaintext: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plaintext, hash);
}
