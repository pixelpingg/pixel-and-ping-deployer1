import { NextFunction, Request, Response } from "express";
import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { verifyApiKey } from "../lib/apiKey";
import { ApiKeyScope } from "@prisma/client";

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      apiKey?: { id: string; scopes: ApiKeyScope[] };
    }
  }
}

/**
 * Authenticates ingestion requests from an authorized external caller
 * (a VPN daemon, a metering sidecar, etc) using a long-lived API key —
 * entirely separate from the admin session/JWT system in
 * middleware/auth.ts. Expected header:
 *
 *   Authorization: Bearer pp_live_<key>
 *
 * Keys are created via POST /api/api-keys (admin session required) and
 * are shown in full exactly once. Only a bcrypt hash is stored; this
 * middleware checks the request key against every active key's hash
 * (key count is expected to stay small — tens, not millions — so this
 * is not a bottleneck; swap for a keyed-lookup-by-prefix + hash-compare
 * scheme if you provision thousands of keys).
 */
export function requireApiKey(...requiredScopes: ApiKeyScope[]) {
  return async (req: Request, _res: Response, next: NextFunction) => {
    try {
      const header = req.headers.authorization;
      if (!header?.startsWith("Bearer ")) {
        throw ApiError.unauthorized("Missing API key. Send 'Authorization: Bearer <key>'.");
      }
      const presented = header.slice("Bearer ".length).trim();
      if (!presented.startsWith("pp_live_")) {
        throw ApiError.unauthorized("Malformed API key");
      }

      const prefix = presented.slice(0, 16);
      const candidates = await prisma.apiKey.findMany({
        where: { keyPrefix: prefix, isActive: true, revokedAt: null },
      });

      let matched: (typeof candidates)[number] | undefined;
      for (const candidate of candidates) {
        if (await verifyApiKey(presented, candidate.keyHash)) {
          matched = candidate;
          break;
        }
      }

      if (!matched) throw ApiError.unauthorized("Invalid or revoked API key");

      if (requiredScopes.length > 0) {
        const hasScope =
          matched.scopes.includes(ApiKeyScope.FULL_INGEST) ||
          requiredScopes.some((s) => matched!.scopes.includes(s));
        if (!hasScope) throw ApiError.forbidden("This API key does not have the required scope");
      }

      await prisma.apiKey.update({ where: { id: matched.id }, data: { lastUsedAt: new Date() } });

      req.apiKey = { id: matched.id, scopes: matched.scopes };
      next();
    } catch (err) {
      if (err instanceof ApiError) return next(err);
      next(ApiError.unauthorized("API key validation failed"));
    }
  };
}
