import { NextFunction, Request, Response } from "express";
import jwt from "jsonwebtoken";
import { env } from "../lib/env";
import { prisma } from "../lib/prisma";
import { ApiError } from "../lib/errors";
import { AdminRole } from "@prisma/client";

export interface AuthPayload {
  adminId: string;
  role: AdminRole;
  sessionId: string;
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      auth?: AuthPayload;
    }
  }
}

// Reads the access token from the httpOnly cookie (never from
// localStorage — the frontend never touches this token directly).
export async function requireAuth(req: Request, _res: Response, next: NextFunction) {
  try {
    const token = req.cookies?.[env.SESSION_COOKIE_NAME];
    if (!token) throw ApiError.unauthorized();

    const payload = jwt.verify(token, env.JWT_SECRET) as AuthPayload;

    const session = await prisma.session.findUnique({ where: { id: payload.sessionId } });
    if (!session || session.revokedAt || session.expiresAt < new Date()) {
      throw ApiError.unauthorized("Session expired. Please log in again.");
    }

    const admin = await prisma.admin.findUnique({ where: { id: payload.adminId } });
    if (!admin || !admin.isActive) {
      throw ApiError.unauthorized("Account disabled");
    }

    req.auth = { adminId: admin.id, role: admin.role, sessionId: session.id };
    next();
  } catch (err) {
    if (err instanceof ApiError) return next(err);
    next(ApiError.unauthorized("Invalid or expired session"));
  }
}

// Role-based access control. SUPER_ADMIN implicitly passes every check.
export function requireRole(...roles: AdminRole[]) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.auth) return next(ApiError.unauthorized());
    if (req.auth.role === AdminRole.SUPER_ADMIN) return next();
    if (!roles.includes(req.auth.role)) {
      return next(ApiError.forbidden("Your role does not permit this action"));
    }
    next();
  };
}
