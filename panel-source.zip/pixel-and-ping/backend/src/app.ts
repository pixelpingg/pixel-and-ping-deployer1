import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import { env } from "./lib/env";
import { errorHandler, notFoundHandler } from "./middleware/errorHandler";
import { apiRateLimiter } from "./middleware/rateLimit";

import { authRouter } from "./routes/auth";
import { twoFactorRouter } from "./routes/twoFactor";
import { usersRouter } from "./routes/users";
import { serversRouter } from "./routes/servers";
import { endpointsRouter } from "./routes/endpoints";
import { cloudflareRouter } from "./routes/cloudflare";
import { portsRouter } from "./routes/ports";
import { configsRouter } from "./routes/configs";
import { trafficRouter } from "./routes/traffic";
import { analyticsRouter } from "./routes/analytics";
import { healthRouter } from "./routes/health";
import { failoverRouter } from "./routes/failover";
import { logsRouter } from "./routes/logs";
import { notificationsRouter } from "./routes/notifications";
import { settingsRouter } from "./routes/settings";
import { apiKeysRouter } from "./routes/apiKeys";
import { ingestRouter } from "./routes/ingest";

export function createApp() {
  const app = express();

  app.set("trust proxy", 1);

  app.use(
    helmet({
      contentSecurityPolicy: env.NODE_ENV === "production" ? undefined : false,
    })
  );
  app.use(
    cors({
      origin: env.FRONTEND_ORIGIN,
      credentials: true,
    })
  );
  app.use(express.json({ limit: "1mb" }));
  app.use(cookieParser());
  app.use(apiRateLimiter);

  app.get("/api/health", (_req, res) => res.json({ ok: true, version: "1.1.1" }));

  app.use("/api/auth/2fa", twoFactorRouter);
  app.use("/api/auth", authRouter);
  app.use("/api/users", usersRouter);
  app.use("/api/servers", serversRouter);
  app.use("/api/endpoints", endpointsRouter);
  app.use("/api/cloudflare", cloudflareRouter);
  app.use("/api/ports", portsRouter);
  app.use("/api/configs", configsRouter);
  app.use("/api/traffic", trafficRouter);
  app.use("/api/analytics", analyticsRouter);
  app.use("/api/health-checks", healthRouter);
  app.use("/api/failover", failoverRouter);
  app.use("/api/logs", logsRouter);
  app.use("/api/notifications", notificationsRouter);
  app.use("/api/settings", settingsRouter);
  app.use("/api/api-keys", apiKeysRouter);
  app.use("/api/ingest", ingestRouter);

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
