import "./lib/bigintJson";
import { createApp } from "./app";
import { env } from "./lib/env";
import { logger } from "./lib/logger";
import { startScheduler } from "./services/scheduler";

const app = createApp();

app.listen(env.PORT, () => {
  logger.info(`Pixel & Ping backend listening on port ${env.PORT}`);
  startScheduler();
});

process.on("unhandledRejection", (reason) => {
  logger.error("Unhandled promise rejection", { reason: reason instanceof Error ? reason.message : reason });
});
