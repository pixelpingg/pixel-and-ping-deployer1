# Migrations

No SQL migration files are checked into this repo. This environment has
no network access, so `npx prisma migrate dev` could not be run against a
real Postgres instance to generate one — and a hand-written migration
would risk drifting from what Prisma actually generates from
`schema.prisma`.

**Run this yourself, once, against a real database:**

```bash
cd backend
npx prisma migrate dev --name init
```

This reads `schema.prisma` (already complete and internally consistent —
20 models, 9 enums, all relations paired, see the file itself) and
generates the proper timestamped migration folder here, then applies it.

For every schema change after that, repeat with a descriptive name:

```bash
npx prisma migrate dev --name add_two_factor_and_ingestion
```

In production, use `npx prisma migrate deploy` (already wired into the
`backend` service's Docker Compose command) instead of `migrate dev`.
