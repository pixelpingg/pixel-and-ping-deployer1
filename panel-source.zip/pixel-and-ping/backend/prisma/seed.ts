import { PrismaClient, AdminRole, PortType } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("ChangeMe123!", 12);

  const superAdmin = await prisma.admin.upsert({
    where: { email: "admin@pixelping.local" },
    update: {},
    create: {
      email: "admin@pixelping.local",
      username: "admin",
      passwordHash,
      role: AdminRole.SUPER_ADMIN,
    },
  });
  console.log(`Seeded super admin: ${superAdmin.username} (password: ChangeMe123! — change immediately)`);

  const wellKnownTls = [443, 8443, 2053, 2083, 2087, 2096];
  const wellKnownNonTls = [80, 8080, 2052, 2082, 2086, 2095];

  for (const number of wellKnownTls) {
    await prisma.port.upsert({
      where: { number },
      update: {},
      create: { number, type: PortType.TLS, isReserved: true, label: "Well-known TLS port" },
    });
  }
  for (const number of wellKnownNonTls) {
    await prisma.port.upsert({
      where: { number },
      update: {},
      create: { number, type: PortType.NON_TLS, isReserved: true, label: "Well-known non-TLS port" },
    });
  }

  await prisma.failoverSettings.upsert({
    where: { id: (await prisma.failoverSettings.findFirst())?.id ?? "seed-default" },
    update: {},
    create: {
      id: "seed-default",
      enabled: false,
      failureThreshold: 3,
      retryCount: 2,
      healthCheckIntervalSec: 30,
      recoveryThreshold: 2,
    },
  });

  console.log("Seed complete.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
